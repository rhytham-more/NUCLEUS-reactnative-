import { NavigationContainer } from "@react-navigation/native"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import { createNativeStackNavigator } from "@react-navigation/native-stack"
import { StatusBar } from "react-native"

// Screens
import HomeScreen from "./src/screens/HomeScreen"
import BookTestScreen from "./src/screens/BookTestScreen"
import ReportsScreen from "./src/screens/ReportsScreen"
import HealthScreen from "./src/screens/HealthScreen"
import ContactScreen from "./src/screens/ContactScreen"
import AboutScreen from "./src/screens/AboutScreen"
import DoctorsScreen from "./src/screens/DoctorsScreen"

// Simple icon component
import TabIcon from "./src/components/TabIcon"

const Tab = createBottomTabNavigator()
const Stack = createNativeStackNavigator()

const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: "#1E3A8A",
        tabBarInactiveTintColor: "#6B7280",
        tabBarStyle: {
          backgroundColor: "#FFFFFF",
          borderTopColor: "#E5E7EB",
          paddingBottom: 8,
          paddingTop: 8,
          height: 60,
        },
        headerShown: false,
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({ color }) => <TabIcon name="home" color={color} />,
        }}
      />
      <Tab.Screen
        name="BookTest"
        component={BookTestScreen}
        options={{
          tabBarLabel: "Book Test",
          tabBarIcon: ({ color }) => <TabIcon name="test" color={color} />,
        }}
      />
      <Tab.Screen
        name="Reports"
        component={ReportsScreen}
        options={{
          tabBarIcon: ({ color }) => <TabIcon name="report" color={color} />,
        }}
      />
      <Tab.Screen
        name="Health"
        component={HealthScreen}
        options={{
          tabBarIcon: ({ color }) => <TabIcon name="health" color={color} />,
        }}
      />
      <Tab.Screen
        name="Contact"
        component={ContactScreen}
        options={{
          tabBarIcon: ({ color }) => <TabIcon name="contact" color={color} />,
        }}
      />
    </Tab.Navigator>
  )
}

const App = () => {
  return (
    <NavigationContainer>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <Stack.Navigator>
        <Stack.Screen name="MainTabs" component={TabNavigator} options={{ headerShown: false }} />
        <Stack.Screen name="About" component={AboutScreen} options={{ title: "About NUCLEUS" }} />
        <Stack.Screen name="Doctors" component={DoctorsScreen} options={{ title: "Our Doctors" }} />
      </Stack.Navigator>
    </NavigationContainer>
  )
}

export default App
