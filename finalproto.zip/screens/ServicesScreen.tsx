import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { StatusBar } from "expo-status-bar"
import Header from "../components/Header"
import BottomTabBar from "../components/BottomTabBar"
import { Ionicons } from "@expo/vector-icons"

const ServicesScreen = () => {
  const services = [
    {
      id: "1",
      title: "Complete Blood Count (CBC)",
      description:
        "Measures different components of your blood including red and white blood cells, platelets, and hemoglobin.",
      icon: "water",
    },
    {
      id: "2",
      title: "Lipid Profile",
      description: "Measures cholesterol levels to assess risk of heart disease.",
      icon: "heart",
    },
    {
      id: "3",
      title: "Liver Function Test",
      description: "Evaluates how well your liver is working by measuring proteins, liver enzymes, and bilirubin.",
      icon: "medkit",
    },
    {
      id: "4",
      title: "Kidney Function Test",
      description: "Assesses how well your kidneys are functioning by measuring various substances in your blood.",
      icon: "filter",
    },
    {
      id: "5",
      title: "Thyroid Function Test",
      description: "Checks the function of your thyroid gland by measuring hormone levels.",
      icon: "thermometer",
    },
    {
      id: "6",
      title: "Blood Glucose Test",
      description: "Measures the amount of glucose in your blood to screen for diabetes.",
      icon: "pulse",
    },
    {
      id: "7",
      title: "Urine Analysis",
      description: "Examines the content of your urine for various substances.",
      icon: "flask",
    },
    {
      id: "8",
      title: "Doctor Consultation",
      description: "One-on-one consultation with our experienced doctors.",
      icon: "people",
    },
  ]

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <Header showBackButton />

      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>Our Services</Text>
          <Text style={styles.subtitle}>Comprehensive healthcare services for all your needs</Text>
        </View>

        <View style={styles.servicesContainer}>
          {services.map((service) => (
            <TouchableOpacity key={service.id} style={styles.serviceCard}>
              <View style={styles.iconContainer}>
                <Ionicons name={service.icon} size={28} color="#2196F3" />
              </View>
              <View style={styles.serviceContent}>
                <Text style={styles.serviceTitle}>{service.title}</Text>
                <Text style={styles.serviceDescription}>{service.description}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.packageSection}>
          <Text style={styles.packageTitle}>Health Packages</Text>

          <View style={styles.packageCard}>
            <View style={styles.packageHeader}>
              <Text style={styles.packageName}>Basic Health Checkup</Text>
              <View style={styles.priceBadge}>
                <Text style={styles.priceText}>₹999</Text>
              </View>
            </View>
            <View style={styles.packageContent}>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>Complete Blood Count</Text>
              </View>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>Urine Routine</Text>
              </View>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>Blood Sugar (Fasting)</Text>
              </View>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>Cholesterol Test</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.bookButton}>
              <Text style={styles.bookButtonText}>Book Now</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.packageCard}>
            <View style={styles.packageHeader}>
              <Text style={styles.packageName}>Comprehensive Health Checkup</Text>
              <View style={styles.priceBadge}>
                <Text style={styles.priceText}>₹2499</Text>
              </View>
            </View>
            <View style={styles.packageContent}>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>All Basic Health Checkup Tests</Text>
              </View>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>Liver Function Test</Text>
              </View>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>Kidney Function Test</Text>
              </View>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>Thyroid Profile</Text>
              </View>
              <View style={styles.packageItem}>
                <Ionicons name="checkmark-circle" size={20} color="#4caf50" />
                <Text style={styles.packageItemText}>Doctor Consultation</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.bookButton}>
              <Text style={styles.bookButtonText}>Book Now</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      <BottomTabBar />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: "#2196F3",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: "#e3f2fd",
  },
  servicesContainer: {
    padding: 16,
  },
  serviceCard: {
    flexDirection: "row",
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#e3f2fd",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 16,
  },
  serviceContent: {
    flex: 1,
  },
  serviceTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333333",
    marginBottom: 4,
  },
  serviceDescription: {
    fontSize: 14,
    color: "#666666",
  },
  packageSection: {
    padding: 16,
  },
  packageTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333333",
    marginBottom: 16,
  },
  packageCard: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  packageHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#e3f2fd",
    padding: 16,
  },
  packageName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333333",
  },
  priceBadge: {
    backgroundColor: "#2196F3",
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 16,
  },
  priceText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
  packageContent: {
    padding: 16,
  },
  packageItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  packageItemText: {
    marginLeft: 8,
    fontSize: 14,
    color: "#666666",
  },
  bookButton: {
    backgroundColor: "#2196F3",
    padding: 12,
    alignItems: "center",
  },
  bookButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
})

export default ServicesScreen
