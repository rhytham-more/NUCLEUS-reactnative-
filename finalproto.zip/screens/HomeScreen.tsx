import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useNavigation } from "@react-navigation/native"
import { StatusBar } from "expo-status-bar"
import Header from "../components/Header"
import BottomTabBar from "../components/BottomTabBar"
import AppointmentButton from "../components/AppointmentButton"
import ServiceCard from "../components/ServiceCard"
import { Ionicons } from "@expo/vector-icons"

const HomeScreen = () => {
  const navigation = useNavigation()

  const services = [
    {
      id: "1",
      title: "Pathology Tests",
      description: "Comprehensive blood and tissue analysis",
      icon: "flask",
    },
    {
      id: "2",
      title: "Health Checkups",
      description: "Complete health assessment packages",
      icon: "fitness",
    },
    {
      id: "3",
      title: "Consultations",
      description: "Expert medical consultations",
      icon: "people",
    },
  ]

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <Header />

      <ScrollView style={styles.scrollView}>
        <View style={styles.heroSection}>
          <View style={styles.heroContent}>
            <Text style={styles.heroTitle}>Nucleus Pathology Laboratory and Clinic</Text>
            <Text style={styles.heroSubtitle}>Your Health Is Our Priority</Text>
            <Text style={styles.heroDescription}>
              Providing high-quality healthcare services to patients of all ages in Indira Nagar, Nashik.
            </Text>
            <View style={styles.buttonContainer}>
              <AppointmentButton />
              <TouchableOpacity style={styles.secondaryButton} onPress={() => navigation.navigate("Services")}>
                <Text style={styles.secondaryButtonText}>Our Services</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <View style={styles.contactCard}>
          <View style={styles.contactHeader}>
            <Ionicons name="call" size={20} color="#e53935" />
            <Text style={styles.contactHeaderText}>Emergency Contact</Text>
          </View>
          <TouchableOpacity
            style={styles.phoneContainer}
            onPress={() => {
              /* Handle phone call */
            }}
          >
            <Text style={styles.phoneNumber}>9890 60 9022</Text>
            <Text style={styles.phoneNumber}>0253 - 4060600</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Our Services</Text>
          <View style={styles.servicesContainer}>
            {services.map((service) => (
              <ServiceCard
                key={service.id}
                title={service.title}
                description={service.description}
                icon={service.icon}
                onPress={() => navigation.navigate("Services")}
              />
            ))}
          </View>
          <TouchableOpacity style={styles.viewAllButton} onPress={() => navigation.navigate("Services")}>
            <Text style={styles.viewAllText}>View All Services</Text>
            <Ionicons name="arrow-forward" size={16} color="#2196F3" />
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Why Choose Us</Text>
          <View style={styles.featureContainer}>
            <View style={styles.feature}>
              <View style={styles.featureIconContainer}>
                <Ionicons name="medal" size={24} color="#2196F3" />
              </View>
              <Text style={styles.featureTitle}>Expert Doctors</Text>
              <Text style={styles.featureDescription}>Highly qualified and experienced medical professionals</Text>
            </View>

            <View style={styles.feature}>
              <View style={styles.featureIconContainer}>
                <Ionicons name="time" size={24} color="#2196F3" />
              </View>
              <Text style={styles.featureTitle}>Quick Results</Text>
              <Text style={styles.featureDescription}>Fast and accurate test results</Text>
            </View>

            <View style={styles.feature}>
              <View style={styles.featureIconContainer}>
                <Ionicons name="shield-checkmark" size={24} color="#2196F3" />
              </View>
              <Text style={styles.featureTitle}>Quality Assured</Text>
              <Text style={styles.featureDescription}>State-of-the-art equipment and procedures</Text>
            </View>
          </View>
        </View>
      </ScrollView>

      <BottomTabBar />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
  },
  scrollView: {
    flex: 1,
  },
  heroSection: {
    backgroundColor: "#2196F3",
    paddingTop: 30,
    paddingBottom: 40,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  heroContent: {
    paddingHorizontal: 20,
  },
  heroTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 8,
  },
  heroSubtitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#ffffff",
    marginBottom: 12,
  },
  heroDescription: {
    fontSize: 14,
    color: "#e3f2fd",
    marginBottom: 24,
  },
  buttonContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  secondaryButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 25,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    alignItems: "center",
    justifyContent: "center",
  },
  secondaryButtonText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "600",
  },
  contactCard: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 20,
    marginTop: -20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
  },
  contactHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  contactHeaderText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#e53935",
    marginLeft: 8,
  },
  phoneContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 8,
  },
  phoneNumber: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333333",
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333333",
    marginBottom: 16,
  },
  servicesContainer: {
    marginBottom: 16,
  },
  viewAllButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
  },
  viewAllText: {
    fontSize: 14,
    color: "#2196F3",
    marginRight: 4,
  },
  featureContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  feature: {
    width: "30%",
    alignItems: "center",
    marginBottom: 16,
  },
  featureIconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#e3f2fd",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  featureTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333333",
    marginBottom: 4,
    textAlign: "center",
  },
  featureDescription: {
    fontSize: 12,
    color: "#666666",
    textAlign: "center",
  },
})

export default HomeScreen
