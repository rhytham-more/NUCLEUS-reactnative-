const mongoose = require("mongoose")

const testSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Test name is required"],
      trim: true,
    },
    code: {
      type: String,
      required: [true, "Test code is required"],
      unique: true,
      uppercase: true,
    },
    description: {
      type: String,
      required: [true, "Test description is required"],
    },
    category: {
      type: String,
      required: [true, "Test category is required"],
      enum: ["blood", "urine", "pathology", "radiology", "cardiology", "other"],
    },
    price: {
      type: Number,
      required: [true, "Test price is required"],
      min: [0, "Price cannot be negative"],
    },
    discountedPrice: {
      type: Number,
      min: [0, "Discounted price cannot be negative"],
    },
    duration: {
      type: String,
      required: [true, "Test duration is required"],
    },
    preparation: {
      type: String,
      required: [true, "Test preparation instructions are required"],
    },
    sampleType: {
      type: String,
      required: [true, "Sample type is required"],
      enum: ["blood", "urine", "stool", "saliva", "tissue", "other"],
    },
    fastingRequired: {
      type: Boolean,
      default: false,
    },
    fastingHours: {
      type: Number,
      default: 0,
    },
    normalRanges: [
      {
        parameter: String,
        unit: String,
        maleRange: String,
        femaleRange: String,
        childRange: String,
      },
    ],
    isActive: {
      type: Boolean,
      default: true,
    },
    isPopular: {
      type: Boolean,
      default: false,
    },
    homeCollectionAvailable: {
      type: Boolean,
      default: true,
    },
    reportDeliveryTime: {
      type: String,
      default: "24 hours",
    },
  },
  {
    timestamps: true,
  },
)

module.exports = mongoose.model("Test", testSchema)
