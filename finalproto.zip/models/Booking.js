const mongoose = require("mongoose")

const bookingSchema = new mongoose.Schema(
  {
    bookingId: {
      type: String,
      unique: true,
      required: true,
    },
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    tests: [
      {
        test: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Test",
          required: true,
        },
        quantity: {
          type: Number,
          default: 1,
        },
      },
    ],
    totalAmount: {
      type: Number,
      required: true,
    },
    discountAmount: {
      type: Number,
      default: 0,
    },
    finalAmount: {
      type: Number,
      required: true,
    },
    paymentStatus: {
      type: String,
      enum: ["pending", "paid", "failed", "refunded"],
      default: "pending",
    },
    paymentMethod: {
      type: String,
      enum: ["online", "cash", "card"],
    },
    paymentId: String,
    bookingType: {
      type: String,
      enum: ["lab_visit", "home_collection"],
      required: true,
    },
    appointmentDate: {
      type: Date,
      required: true,
    },
    appointmentTime: {
      type: String,
      required: true,
    },
    collectionAddress: {
      street: String,
      city: String,
      state: String,
      pincode: String,
      landmark: String,
    },
    status: {
      type: String,
      enum: ["booked", "confirmed", "sample_collected", "processing", "completed", "cancelled"],
      default: "booked",
    },
    assignedPhlebotomist: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    sampleCollectionTime: Date,
    notes: String,
    cancellationReason: String,
    refundAmount: Number,
    refundStatus: {
      type: String,
      enum: ["not_applicable", "pending", "processed"],
      default: "not_applicable",
    },
  },
  {
    timestamps: true,
  },
)

// Generate booking ID before saving
bookingSchema.pre("save", async function (next) {
  if (!this.bookingId) {
    const count = await mongoose.model("Booking").countDocuments()
    this.bookingId = `NUC${Date.now()}${String(count + 1).padStart(4, "0")}`
  }
  next()
})

module.exports = mongoose.model("Booking", bookingSchema)
