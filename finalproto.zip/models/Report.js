const mongoose = require("mongoose")

const reportSchema = new mongoose.Schema(
  {
    reportId: {
      type: String,
      unique: true,
      required: true,
    },
    booking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Booking",
      required: true,
    },
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    test: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Test",
      required: true,
    },
    results: [
      {
        parameter: String,
        value: String,
        unit: String,
        normalRange: String,
        status: {
          type: String,
          enum: ["normal", "high", "low", "critical"],
          default: "normal",
        },
        flag: String,
      },
    ],
    overallStatus: {
      type: String,
      enum: ["normal", "abnormal", "critical"],
      default: "normal",
    },
    doctorComments: String,
    technicalComments: String,
    reportedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    reportDate: {
      type: Date,
      default: Date.now,
    },
    reportFile: {
      filename: String,
      path: String,
      size: Number,
      mimetype: String,
    },
    isDigitallySigned: {
      type: Boolean,
      default: false,
    },
    digitalSignature: String,
    status: {
      type: String,
      enum: ["draft", "pending_verification", "verified", "delivered"],
      default: "draft",
    },
    deliveryMethod: {
      type: String,
      enum: ["email", "sms", "app", "physical"],
      default: "app",
    },
    viewedBy: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        viewedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    downloadCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  },
)

// Generate report ID before saving
reportSchema.pre("save", async function (next) {
  if (!this.reportId) {
    const count = await mongoose.model("Report").countDocuments()
    this.reportId = `RPT${Date.now()}${String(count + 1).padStart(4, "0")}`
  }
  next()
})

module.exports = mongoose.model("Report", reportSchema)
