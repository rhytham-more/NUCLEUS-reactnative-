"use client"

import { useState } from "react"
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Alert } from "react-native"
import Header from "../components/Header"

const ReportsScreen = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [loginMethod, setLoginMethod] = useState("otp")
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [otp, setOtp] = useState("")

  const mockReports = [
    {
      id: "1",
      testName: "Complete Blood Count (CBC)",
      date: "2024-01-15",
      status: "Normal",
    },
    {
      id: "2",
      testName: "Lipid Profile",
      date: "2024-01-10",
      status: "Abnormal",
    },
  ]

  const handleLogin = () => {
    if (loginMethod === "otp") {
      if (!phone || !otp) {
        Alert.alert("Error", "Please enter phone number and OTP")
        return
      }
    } else {
      if (!phone || !password) {
        Alert.alert("Error", "Please enter phone number and password")
        return
      }
    }
    setIsLoggedIn(true)
  }

  const handleSendOTP = () => {
    if (!phone) {
      Alert.alert("Error", "Please enter phone number")
      return
    }
    Alert.alert("OTP Sent", "OTP has been sent to your phone number")
  }

  const handleDownloadReport = (reportId: string) => {
    Alert.alert("Download", `Downloading report ${reportId}`)
  }

  const handleAIInterpretation = (reportId: string) => {
    Alert.alert(
      "AI Interpretation",
      "Your CBC results show normal values across all parameters. White blood cell count is within healthy range.",
    )
  }

  if (!isLoggedIn) {
    return (
      <View style={styles.container}>
        <Header title="My Reports" />
        <ScrollView style={styles.loginContainer}>
          <View style={styles.loginHeader}>
            <Text style={styles.lockIcon}>🔒</Text>
            <Text style={styles.loginTitle}>Secure Login Required</Text>
            <Text style={styles.loginSubtitle}>Access your reports securely with OTP or password</Text>
          </View>

          <View style={styles.loginMethodToggle}>
            <TouchableOpacity
              style={[styles.toggleButton, loginMethod === "otp" && styles.activeToggleButton]}
              onPress={() => setLoginMethod("otp")}
            >
              <Text style={[styles.toggleButtonText, loginMethod === "otp" && styles.activeToggleButtonText]}>
                Login with OTP
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.toggleButton, loginMethod === "password" && styles.activeToggleButton]}
              onPress={() => setLoginMethod("password")}
            >
              <Text style={[styles.toggleButtonText, loginMethod === "password" && styles.activeToggleButtonText]}>
                Login with Password
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.loginForm}>
            <View style={styles.inputContainer}>
              <Text style={styles.inputIcon}>📱</Text>
              <TextInput
                style={styles.input}
                placeholder="Phone Number"
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                placeholderTextColor="#6B7280"
              />
            </View>

            {loginMethod === "otp" ? (
              <>
                <TouchableOpacity style={styles.sendOTPButton} onPress={handleSendOTP}>
                  <Text style={styles.sendOTPButtonText}>Send OTP</Text>
                </TouchableOpacity>
                <View style={styles.inputContainer}>
                  <Text style={styles.inputIcon}>💬</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter OTP"
                    value={otp}
                    onChangeText={setOtp}
                    keyboardType="numeric"
                    placeholderTextColor="#6B7280"
                  />
                </View>
              </>
            ) : (
              <View style={styles.inputContainer}>
                <Text style={styles.inputIcon}>🔒</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Password"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                  placeholderTextColor="#6B7280"
                />
              </View>
            )}

            <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
              <Text style={styles.loginButtonText}>Login</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.featuresPreview}>
            <Text style={styles.featuresTitle}>What you'll get access to:</Text>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>📥</Text>
              <Text style={styles.featureText}>Download digitally signed PDF reports</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>🤖</Text>
              <Text style={styles.featureText}>AI interpretation of your results</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>📈</Text>
              <Text style={styles.featureText}>Track health trends over time</Text>
            </View>
          </View>
        </ScrollView>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <View style={styles.reportsHeader}>
        <Text style={styles.reportsTitle}>My Reports</Text>
        <TouchableOpacity onPress={() => setIsLoggedIn(false)}>
          <Text style={styles.logoutIcon}>🚪</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.reportsContainer}>
        {mockReports.map((report) => (
          <View key={report.id} style={styles.reportCard}>
            <View style={styles.reportHeader}>
              <Text style={styles.reportName}>{report.testName}</Text>
              <View
                style={[styles.statusBadge, report.status === "Normal" ? styles.normalStatus : styles.abnormalStatus]}
              >
                <Text style={styles.statusText}>{report.status}</Text>
              </View>
            </View>
            <Text style={styles.reportDate}>Date: {report.date}</Text>

            <View style={styles.reportActions}>
              <TouchableOpacity style={styles.actionButton} onPress={() => handleDownloadReport(report.id)}>
                <Text style={styles.actionIcon}>📥</Text>
                <Text style={styles.actionButtonText}>Download</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton} onPress={() => handleAIInterpretation(report.id)}>
                <Text style={styles.actionIcon}>🤖</Text>
                <Text style={styles.actionButtonText}>AI Interpret</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },
  loginContainer: {
    flex: 1,
    paddingHorizontal: 16,
  },
  loginHeader: {
    alignItems: "center",
    paddingVertical: 32,
  },
  lockIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  loginTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 8,
  },
  loginSubtitle: {
    fontSize: 16,
    color: "#6B7280",
    textAlign: "center",
  },
  loginMethodToggle: {
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 4,
    marginBottom: 24,
  },
  toggleButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: "center",
    borderRadius: 8,
  },
  activeToggleButton: {
    backgroundColor: "#1E3A8A",
  },
  toggleButtonText: {
    fontSize: 14,
    color: "#6B7280",
  },
  activeToggleButtonText: {
    color: "#FFFFFF",
    fontWeight: "600",
  },
  loginForm: {
    gap: 16,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  inputIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#1F2937",
  },
  sendOTPButton: {
    backgroundColor: "#10B981",
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: "center",
  },
  sendOTPButtonText: {
    fontSize: 16,
    color: "#FFFFFF",
    fontWeight: "600",
  },
  loginButton: {
    backgroundColor: "#1E3A8A",
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: "center",
  },
  loginButtonText: {
    fontSize: 16,
    color: "#FFFFFF",
    fontWeight: "600",
  },
  featuresPreview: {
    paddingVertical: 24,
  },
  featuresTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 16,
  },
  featureItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  featureIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  featureText: {
    fontSize: 16,
    color: "#6B7280",
  },
  reportsHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
  },
  reportsTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1F2937",
  },
  logoutIcon: {
    fontSize: 24,
  },
  reportsContainer: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  reportCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  reportHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  reportName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    flex: 1,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  normalStatus: {
    backgroundColor: "#D1FAE5",
  },
  abnormalStatus: {
    backgroundColor: "#FEE2E2",
  },
  statusText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#1F2937",
  },
  reportDate: {
    fontSize: 14,
    color: "#6B7280",
    marginBottom: 16,
  },
  reportActions: {
    flexDirection: "row",
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: "#F3F4F6",
    gap: 8,
  },
  actionIcon: {
    fontSize: 20,
  },
  actionButtonText: {
    fontSize: 14,
    color: "#1F2937",
    fontWeight: "500",
  },
})

export default ReportsScreen
