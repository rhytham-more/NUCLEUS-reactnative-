import { View, Text, ScrollView, StyleSheet } from "react-native"
import Header from "../components/Header"

const AboutScreen = () => {
  const features = [
    {
      id: "1",
      icon: "✅",
      title: "NABL Accredited",
      description: "Certified equipment and processes for accurate results",
    },
    {
      id: "2",
      icon: "⏰",
      title: "Quick Reports",
      description: "Fast turnaround time with 24/7 digital access",
    },
    {
      id: "3",
      icon: "🛡️",
      title: "Safe Collection",
      description: "Sanitized sample collection with top safety standards",
    },
    {
      id: "4",
      icon: "👨‍⚕️",
      title: "Expert Team",
      description: "Qualified doctors and certified technicians",
    },
  ]

  return (
    <View style={styles.container}>
      <Header title="About NUCLEUS" showNotification={false} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.heroSection}>
          <Text style={styles.heroTitle}>Expert Diagnostics, Compassionate Care</Text>
          <Text style={styles.heroDescription}>
            NUCLEUS is dedicated to reliable, affordable, and accessible diagnostic services powered by technology and
            humanity.
          </Text>
        </View>

        <View style={styles.missionSection}>
          <Text style={styles.sectionTitle}>Our Mission</Text>
          <Text style={styles.missionText}>
            Making quality healthcare accessible and convenient for all. We strive to provide accurate diagnostic
            services with compassionate care, ensuring every patient receives the attention they deserve.
          </Text>
        </View>

        <View style={styles.featuresSection}>
          <Text style={styles.sectionTitle}>Why Trust NUCLEUS</Text>
          <View style={styles.featuresGrid}>
            {features.map((feature) => (
              <View key={feature.id} style={styles.featureCard}>
                <Text style={styles.featureIcon}>{feature.icon}</Text>
                <Text style={styles.featureTitle}>{feature.title}</Text>
                <Text style={styles.featureDescription}>{feature.description}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.valuesSection}>
          <Text style={styles.sectionTitle}>Our Values</Text>
          <View style={styles.valueItem}>
            <Text style={styles.valueTitle}>Accuracy</Text>
            <Text style={styles.valueDescription}>
              Precise results you can trust for informed healthcare decisions.
            </Text>
          </View>
          <View style={styles.valueItem}>
            <Text style={styles.valueTitle}>Accessibility</Text>
            <Text style={styles.valueDescription}>
              Convenient locations and home collection services for your comfort.
            </Text>
          </View>
          <View style={styles.valueItem}>
            <Text style={styles.valueTitle}>Affordability</Text>
            <Text style={styles.valueDescription}>Quality healthcare services at competitive prices for everyone.</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },
  heroSection: {
    backgroundColor: "#1E3A8A",
    paddingHorizontal: 16,
    paddingVertical: 32,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  heroTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#FFFFFF",
    marginBottom: 16,
    textAlign: "center",
  },
  heroDescription: {
    fontSize: 16,
    color: "#FFFFFF",
    opacity: 0.9,
    textAlign: "center",
    lineHeight: 24,
  },
  missionSection: {
    paddingHorizontal: 16,
    paddingVertical: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 16,
  },
  missionText: {
    fontSize: 16,
    color: "#6B7280",
    lineHeight: 24,
  },
  featuresSection: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  featuresGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    gap: 12,
  },
  featureCard: {
    width: "48%",
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  featureIcon: {
    fontSize: 32,
    marginBottom: 12,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 8,
    textAlign: "center",
  },
  featureDescription: {
    fontSize: 14,
    color: "#6B7280",
    textAlign: "center",
    lineHeight: 20,
  },
  valuesSection: {
    paddingHorizontal: 16,
    paddingBottom: 32,
  },
  valueItem: {
    marginBottom: 16,
  },
  valueTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 4,
  },
  valueDescription: {
    fontSize: 14,
    color: "#6B7280",
    lineHeight: 20,
  },
})

export default AboutScreen
