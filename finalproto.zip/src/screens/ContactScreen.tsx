"use client"

import { useState } from "react"
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Linking, Alert } from "react-native"
import Header from "../components/Header"

const ContactScreen = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })

  const labInfo = {
    name: "NUCLEUS Pathology Laboratory",
    address: "Near Bus Stand, Sinnar, Nashik, Maharashtra 422103",
    phones: ["02555-230724", "02555-230725"],
    email: "info@nucleuslab.com",
    timings: "Mon–Sun: 8:00 AM – 8:00 PM",
  }

  const faqs = [
    {
      question: "How do I book tests?",
      answer: "Use our Book Test section or call us directly",
    },
    {
      question: "How safe is sample collection?",
      answer: "We follow strict safety and hygiene protocols",
    },
    {
      question: "What if I miss my slot?",
      answer: "Contact us immediately to reschedule",
    },
  ]

  const handleCall = (phoneNumber: string) => {
    Linking.openURL(`tel:${phoneNumber}`)
  }

  const handleEmail = () => {
    Linking.openURL(`mailto:${labInfo.email}`)
  }

  const handleGetDirections = () => {
    const encodedAddress = encodeURIComponent(labInfo.address)
    Linking.openURL(`https://maps.google.com/?q=${encodedAddress}`)
  }

  const handleSubmitForm = () => {
    if (!formData.name || !formData.email || !formData.phone || !formData.message) {
      Alert.alert("Error", "Please fill all fields")
      return
    }
    Alert.alert("Success", "Your message has been sent successfully!")
    setFormData({ name: "", email: "", phone: "", message: "" })
  }

  const handleLiveChat = () => {
    Alert.alert("Live Chat", "Connecting you to our support team...")
  }

  const handleCallback = () => {
    Alert.alert("Callback Request", "We will call you back within 30 minutes")
  }

  return (
    <View style={styles.container}>
      <Header title="Contact & Support" />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Lab Information */}
        <View style={styles.labInfoSection}>
          <Text style={styles.sectionTitle}>{labInfo.name}</Text>

          <View style={styles.infoItem}>
            <Text style={styles.infoIcon}>📍</Text>
            <View style={styles.infoContent}>
              <Text style={styles.infoText}>{labInfo.address}</Text>
              <TouchableOpacity onPress={handleGetDirections}>
                <Text style={styles.linkText}>Get Directions</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.infoItem}>
            <Text style={styles.infoIcon}>📞</Text>
            <View style={styles.infoContent}>
              {labInfo.phones.map((phone, index) => (
                <TouchableOpacity key={index} onPress={() => handleCall(phone)}>
                  <Text style={styles.linkText}>{phone}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.infoItem}>
            <Text style={styles.infoIcon}>📧</Text>
            <View style={styles.infoContent}>
              <TouchableOpacity onPress={handleEmail}>
                <Text style={styles.linkText}>{labInfo.email}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.infoItem}>
            <Text style={styles.infoIcon}>⏰</Text>
            <View style={styles.infoContent}>
              <Text style={styles.infoText}>{labInfo.timings}</Text>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>Quick Support</Text>
          <View style={styles.quickActionsGrid}>
            <TouchableOpacity style={styles.quickActionButton} onPress={handleLiveChat}>
              <Text style={styles.quickActionIcon}>💬</Text>
              <Text style={styles.quickActionText}>Live Chat</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickActionButton} onPress={() => handleCall(labInfo.phones[0])}>
              <Text style={styles.quickActionIcon}>📞</Text>
              <Text style={styles.quickActionText}>Call Now</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickActionButton} onPress={handleCallback}>
              <Text style={styles.quickActionIcon}>📲</Text>
              <Text style={styles.quickActionText}>Callback</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Contact Form */}
        <View style={styles.formSection}>
          <Text style={styles.sectionTitle}>Send us a Message</Text>
          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={styles.inputIcon}>👤</Text>
              <TextInput
                style={styles.input}
                placeholder="Your Name"
                value={formData.name}
                onChangeText={(text) => setFormData({ ...formData, name: text })}
                placeholderTextColor="#6B7280"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputIcon}>📧</Text>
              <TextInput
                style={styles.input}
                placeholder="Email Address"
                value={formData.email}
                onChangeText={(text) => setFormData({ ...formData, email: text })}
                keyboardType="email-address"
                placeholderTextColor="#6B7280"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputIcon}>📱</Text>
              <TextInput
                style={styles.input}
                placeholder="Phone Number"
                value={formData.phone}
                onChangeText={(text) => setFormData({ ...formData, phone: text })}
                keyboardType="phone-pad"
                placeholderTextColor="#6B7280"
              />
            </View>

            <View style={styles.textAreaContainer}>
              <Text style={styles.inputIcon}>💬</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Your Message"
                value={formData.message}
                onChangeText={(text) => setFormData({ ...formData, message: text })}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                placeholderTextColor="#6B7280"
              />
            </View>

            <TouchableOpacity style={styles.submitButton} onPress={handleSubmitForm}>
              <Text style={styles.submitButtonText}>Send Message</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* FAQ Section */}
        <View style={styles.faqSection}>
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
          {faqs.map((faq, index) => (
            <View key={index} style={styles.faqItem}>
              <Text style={styles.faqQuestion}>{faq.question}</Text>
              <Text style={styles.faqAnswer}>{faq.answer}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 16,
  },
  labInfoSection: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  infoItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 16,
  },
  infoIcon: {
    fontSize: 24,
    marginRight: 12,
    width: 32,
  },
  infoContent: {
    flex: 1,
  },
  infoText: {
    fontSize: 16,
    color: "#6B7280",
    lineHeight: 22,
  },
  linkText: {
    fontSize: 16,
    color: "#1E3A8A",
    textDecorationLine: "underline",
  },
  quickActionsSection: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  quickActionButton: {
    flex: 1,
    backgroundColor: "#1E3A8A",
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
    gap: 8,
  },
  quickActionIcon: {
    fontSize: 24,
  },
  quickActionText: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "600",
  },
  formSection: {
    backgroundColor: "#FFFFFF",
    margin: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  form: {
    gap: 16,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  textAreaContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  inputIcon: {
    fontSize: 20,
    marginRight: 12,
    width: 24,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#1F2937",
  },
  textArea: {
    height: 100,
    marginTop: 4,
  },
  submitButton: {
    backgroundColor: "#1E3A8A",
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
  },
  submitButtonText: {
    fontSize: 16,
    color: "#FFFFFF",
    fontWeight: "600",
  },
  faqSection: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  faqItem: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  faqQuestion: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 4,
  },
  faqAnswer: {
    fontSize: 14,
    color: "#6B7280",
    lineHeight: 20,
  },
})

export default ContactScreen
