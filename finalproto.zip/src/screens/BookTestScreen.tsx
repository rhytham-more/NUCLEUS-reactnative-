"use client"

import { useState } from "react"
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Alert } from "react-native"
import Header from "../components/Header"

const BookTestScreen = () => {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedFilter, setSelectedFilter] = useState("All")

  const tests = [
    {
      id: "1",
      name: "Complete Blood Count (CBC)",
      description: "Comprehensive blood health screening",
      price: 299,
      originalPrice: 399,
      duration: "24 hours",
      preparation: "No fasting required",
      isPopular: true,
    },
    {
      id: "2",
      name: "Lipid Profile",
      description: "Cholesterol and cardiovascular risk assessment",
      price: 499,
      originalPrice: 699,
      duration: "24 hours",
      preparation: "Fasting required: 10-12 hours",
      isPopular: true,
    },
    {
      id: "3",
      name: "Thyroid Panel",
      description: "Complete thyroid function assessment",
      price: 699,
      duration: "24 hours",
      preparation: "No fasting required",
      isPopular: false,
    },
    {
      id: "4",
      name: "Diabetes Screening",
      description: "Blood glucose and HbA1c testing",
      price: 399,
      duration: "24 hours",
      preparation: "Fasting required: 8-10 hours",
      isPopular: true,
    },
  ]

  const filters = ["All", "Popular", "Blood Tests", "Health Packages"]

  const filteredTests = tests.filter((test) => {
    const matchesSearch = test.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter = selectedFilter === "All" || (selectedFilter === "Popular" && test.isPopular)
    return matchesSearch && matchesFilter
  })

  const handleBookTest = (testName: string) => {
    Alert.alert("Book Test", `Booking ${testName}...`)
  }

  return (
    <View style={styles.container}>
      <Header title="Book a Test" />

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="Search tests..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholderTextColor="#6B7280"
        />
      </View>

      {/* Filters */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filtersContainer}>
        {filters.map((filter) => (
          <TouchableOpacity
            key={filter}
            style={[styles.filterChip, selectedFilter === filter && styles.activeFilterChip]}
            onPress={() => setSelectedFilter(filter)}
          >
            <Text style={[styles.filterText, selectedFilter === filter && styles.activeFilterText]}>{filter}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Tests List */}
      <ScrollView style={styles.testsContainer}>
        <Text style={styles.sectionTitle}>{selectedFilter === "All" ? "All Tests" : selectedFilter}</Text>
        {filteredTests.map((test) => (
          <View key={test.id} style={styles.testCard}>
            <View style={styles.testHeader}>
              <View style={styles.testTitleContainer}>
                <Text style={styles.testName}>{test.name}</Text>
                {test.isPopular && (
                  <View style={styles.popularBadge}>
                    <Text style={styles.popularText}>Popular</Text>
                  </View>
                )}
              </View>
              <View style={styles.priceContainer}>
                <Text style={styles.price}>₹{test.price}</Text>
                {test.originalPrice && <Text style={styles.originalPrice}>₹{test.originalPrice}</Text>}
              </View>
            </View>

            <Text style={styles.testDescription}>{test.description}</Text>

            <View style={styles.testInfo}>
              <Text style={styles.infoText}>⏰ Reports in {test.duration}</Text>
              <Text style={styles.infoText}>📋 {test.preparation}</Text>
            </View>

            <TouchableOpacity style={styles.bookButton} onPress={() => handleBookTest(test.name)}>
              <Text style={styles.bookButtonText}>Book Now</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    margin: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  searchIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: "#1F2937",
  },
  filtersContainer: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  filterChip: {
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  activeFilterChip: {
    backgroundColor: "#1E3A8A",
    borderColor: "#1E3A8A",
  },
  filterText: {
    fontSize: 14,
    color: "#1F2937",
  },
  activeFilterText: {
    color: "#FFFFFF",
    fontWeight: "600",
  },
  testsContainer: {
    flex: 1,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 16,
  },
  testCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  testHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 8,
  },
  testTitleContainer: {
    flex: 1,
    marginRight: 12,
  },
  testName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 4,
  },
  popularBadge: {
    backgroundColor: "#F59E0B",
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
    alignSelf: "flex-start",
  },
  popularText: {
    fontSize: 12,
    color: "#FFFFFF",
    fontWeight: "600",
  },
  priceContainer: {
    alignItems: "flex-end",
  },
  price: {
    fontSize: 16,
    fontWeight: "700",
    color: "#10B981",
  },
  originalPrice: {
    fontSize: 12,
    color: "#6B7280",
    textDecorationLine: "line-through",
  },
  testDescription: {
    fontSize: 14,
    color: "#6B7280",
    marginBottom: 12,
    lineHeight: 20,
  },
  testInfo: {
    marginBottom: 16,
  },
  infoText: {
    fontSize: 12,
    color: "#6B7280",
    marginBottom: 4,
  },
  bookButton: {
    backgroundColor: "#1E3A8A",
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: "center",
  },
  bookButtonText: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "600",
  },
})

export default BookTestScreen
