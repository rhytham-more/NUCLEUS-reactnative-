import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from "react-native"
import { useNavigation } from "@react-navigation/native"
import Header from "../components/Header"

const HomeScreen = () => {
  const navigation = useNavigation()

  const handleBookTest = () => {
    navigation.navigate("BookTest")
  }

  const handleViewReports = () => {
    navigation.navigate("Reports")
  }

  const handleQuickAction = (action: string) => {
    switch (action) {
      case "book":
        navigation.navigate("BookTest")
        break
      case "reports":
        navigation.navigate("Reports")
        break
      case "doctors":
        navigation.navigate("Doctors")
        break
      case "about":
        navigation.navigate("About")
        break
      default:
        Alert.alert("Coming Soon", `${action} feature coming soon!`)
    }
  }

  return (
    <View style={styles.container}>
      <Header />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Welcome Banner */}
        <View style={styles.banner}>
          <Text style={styles.bannerTitle}>Welcome to NUCLEUS Pathology Lab</Text>
          <Text style={styles.bannerSubtitle}>Your Trusted Diagnostic Partner</Text>
          <Text style={styles.bannerDescription}>
            Book lab tests, schedule home collection, access reports, and more – your health journey begins here.
          </Text>

          <View style={styles.buttonContainer}>
            <TouchableOpacity style={styles.primaryButton} onPress={handleBookTest}>
              <Text style={styles.primaryButtonText}>Book a Test</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.secondaryButton} onPress={handleViewReports}>
              <Text style={styles.secondaryButtonText}>View Reports</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Emergency Contact */}
        <View style={styles.emergencyCard}>
          <Text style={styles.emergencyTitle}>🚨 Emergency Contact</Text>
          <View style={styles.phoneContainer}>
            <Text style={styles.phoneNumber}>02555-230724</Text>
            <Text style={styles.phoneNumber}>02555-230725</Text>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionsGrid}>
            <TouchableOpacity style={styles.actionCard} onPress={() => handleQuickAction("book")}>
              <Text style={styles.actionIcon}>🧪</Text>
              <Text style={styles.actionTitle}>Book Test</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionCard} onPress={() => handleQuickAction("reports")}>
              <Text style={styles.actionIcon}>📄</Text>
              <Text style={styles.actionTitle}>My Reports</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionCard} onPress={() => handleQuickAction("home-sample")}>
              <Text style={styles.actionIcon}>🏠</Text>
              <Text style={styles.actionTitle}>Home Sample</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionCard} onPress={() => handleQuickAction("doctors")}>
              <Text style={styles.actionIcon}>👨‍⚕️</Text>
              <Text style={styles.actionTitle}>Consult Expert</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionCard} onPress={() => handleQuickAction("about")}>
              <Text style={styles.actionIcon}>ℹ️</Text>
              <Text style={styles.actionTitle}>Lab Info</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Why Choose Us */}
        <View style={styles.featuresSection}>
          <Text style={styles.sectionTitle}>Why Choose NUCLEUS</Text>
          <View style={styles.featuresGrid}>
            <View style={styles.featureCard}>
              <Text style={styles.featureIcon}>✅</Text>
              <Text style={styles.featureTitle}>NABL Accredited</Text>
              <Text style={styles.featureDescription}>Certified equipment and processes</Text>
            </View>

            <View style={styles.featureCard}>
              <Text style={styles.featureIcon}>⏰</Text>
              <Text style={styles.featureTitle}>Quick Reports</Text>
              <Text style={styles.featureDescription}>Fast and accurate results</Text>
            </View>

            <View style={styles.featureCard}>
              <Text style={styles.featureIcon}>🛡️</Text>
              <Text style={styles.featureTitle}>Safe Collection</Text>
              <Text style={styles.featureDescription}>Sanitized sample collection</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },
  banner: {
    backgroundColor: "#1E3A8A",
    paddingHorizontal: 16,
    paddingVertical: 32,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  bannerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#FFFFFF",
    marginBottom: 8,
  },
  bannerSubtitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#FFFFFF",
    marginBottom: 12,
  },
  bannerDescription: {
    fontSize: 14,
    color: "#E3F2FD",
    marginBottom: 24,
    lineHeight: 20,
  },
  buttonContainer: {
    flexDirection: "row",
    gap: 12,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: "center",
  },
  primaryButtonText: {
    color: "#1E3A8A",
    fontSize: 16,
    fontWeight: "600",
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#FFFFFF",
  },
  secondaryButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
  emergencyCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginTop: -20,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
  },
  emergencyTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#EF4444",
    marginBottom: 8,
  },
  phoneContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  phoneNumber: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1F2937",
  },
  quickActions: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 16,
  },
  actionsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    gap: 12,
  },
  actionCard: {
    width: "48%",
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  actionIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: "500",
    color: "#1F2937",
    textAlign: "center",
  },
  featuresSection: {
    padding: 16,
  },
  featuresGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  featureCard: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  featureIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  featureTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 4,
    textAlign: "center",
  },
  featureDescription: {
    fontSize: 12,
    color: "#6B7280",
    textAlign: "center",
    lineHeight: 16,
  },
})

export default HomeScreen
