"use client"

import { useState } from "react"
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from "react-native"
import Header from "../components/Header"

const HealthScreen = () => {
  const [currentTipIndex, setCurrentTipIndex] = useState(0)

  const healthTips = [
    {
      id: "1",
      title: "Stay Hydrated",
      description: "Drink 8-10 glasses of water daily for optimal health.",
      icon: "💧",
    },
    {
      id: "2",
      title: "Exercise Regularly",
      description: "Aim for at least 30 minutes of physical activity daily.",
      icon: "🏃‍♂️",
    },
    {
      id: "3",
      title: "Get Quality Sleep",
      description: "Ensure 7-8 hours of quality sleep for better recovery.",
      icon: "😴",
    },
  ]

  const healthArticles = [
    {
      id: "1",
      title: "Why Regular Checkups Matter",
      description: "Learn about the importance of preventive healthcare",
      readTime: "3 min read",
      category: "Prevention",
    },
    {
      id: "2",
      title: "Monsoon Health Tips",
      description: "Stay healthy during the rainy season",
      readTime: "4 min read",
      category: "Seasonal",
    },
    {
      id: "3",
      title: "Understanding Blood Reports",
      description: "A guide to interpreting your test results",
      readTime: "5 min read",
      category: "Education",
    },
  ]

  const handleVideoPress = (title: string) => {
    Alert.alert("Video", `Playing: ${title}`)
  }

  const nextTip = () => {
    setCurrentTipIndex((prev) => (prev + 1) % healthTips.length)
  }

  const prevTip = () => {
    setCurrentTipIndex((prev) => (prev - 1 + healthTips.length) % healthTips.length)
  }

  return (
    <View style={styles.container}>
      <Header title="Health & Wellness" />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Daily Health Tip */}
        <View style={styles.tipSection}>
          <Text style={styles.sectionTitle}>Daily Health Tip</Text>
          <View style={styles.tipCard}>
            <Text style={styles.tipIcon}>{healthTips[currentTipIndex].icon}</Text>
            <Text style={styles.tipTitle}>{healthTips[currentTipIndex].title}</Text>
            <Text style={styles.tipDescription}>{healthTips[currentTipIndex].description}</Text>
            <View style={styles.tipNavigation}>
              <TouchableOpacity style={styles.navButton} onPress={prevTip}>
                <Text style={styles.navButtonText}>←</Text>
              </TouchableOpacity>
              <View style={styles.tipIndicators}>
                {healthTips.map((_, index) => (
                  <View key={index} style={[styles.indicator, index === currentTipIndex && styles.activeIndicator]} />
                ))}
              </View>
              <TouchableOpacity style={styles.navButton} onPress={nextTip}>
                <Text style={styles.navButtonText}>→</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Health Articles */}
        <View style={styles.articlesSection}>
          <Text style={styles.sectionTitle}>Health Articles</Text>
          {healthArticles.map((article) => (
            <TouchableOpacity key={article.id} style={styles.articleCard}>
              <View style={styles.articleContent}>
                <View style={styles.categoryBadge}>
                  <Text style={styles.categoryText}>{article.category}</Text>
                </View>
                <Text style={styles.articleTitle}>{article.title}</Text>
                <Text style={styles.articleDescription}>{article.description}</Text>
                <Text style={styles.readTime}>⏰ {article.readTime}</Text>
              </View>
              <Text style={styles.articleIcon}>📄</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Health Videos */}
        <View style={styles.videosSection}>
          <Text style={styles.sectionTitle}>Quick Health Videos</Text>
          <View style={styles.videoGrid}>
            <TouchableOpacity style={styles.videoCard} onPress={() => handleVideoPress("Proper Hand Hygiene")}>
              <Text style={styles.videoThumbnail}>▶️</Text>
              <Text style={styles.videoTitle}>Proper Hand Hygiene</Text>
              <Text style={styles.videoDuration}>60 seconds</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.videoCard} onPress={() => handleVideoPress("Understanding Blood Reports")}>
              <Text style={styles.videoThumbnail}>▶️</Text>
              <Text style={styles.videoTitle}>Understanding Blood Reports</Text>
              <Text style={styles.videoDuration}>90 seconds</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Wellness Reminder */}
        <View style={styles.reminderSection}>
          <View style={styles.reminderCard}>
            <Text style={styles.reminderIcon}>📅</Text>
            <View style={styles.reminderContent}>
              <Text style={styles.reminderTitle}>Wellness Reminder</Text>
              <Text style={styles.reminderText}>Next wellness checkup recommended: September 2025</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 16,
  },
  tipSection: {
    padding: 16,
  },
  tipCard: {
    backgroundColor: "#10B981",
    borderRadius: 16,
    padding: 24,
    alignItems: "center",
  },
  tipIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  tipTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#FFFFFF",
    marginBottom: 8,
    textAlign: "center",
  },
  tipDescription: {
    fontSize: 16,
    color: "#FFFFFF",
    opacity: 0.9,
    textAlign: "center",
    lineHeight: 24,
    marginBottom: 16,
  },
  tipNavigation: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
  navButton: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    borderRadius: 20,
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  navButtonText: {
    fontSize: 20,
    color: "#FFFFFF",
  },
  tipIndicators: {
    flexDirection: "row",
    gap: 8,
  },
  indicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "rgba(255, 255, 255, 0.4)",
  },
  activeIndicator: {
    backgroundColor: "#FFFFFF",
  },
  articlesSection: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  articleCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: "row",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  articleContent: {
    flex: 1,
    marginRight: 16,
  },
  categoryBadge: {
    backgroundColor: "#E0E7FF",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: "flex-start",
    marginBottom: 8,
  },
  categoryText: {
    fontSize: 12,
    color: "#1E3A8A",
    fontWeight: "600",
  },
  articleTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 4,
  },
  articleDescription: {
    fontSize: 14,
    color: "#6B7280",
    lineHeight: 20,
    marginBottom: 8,
  },
  readTime: {
    fontSize: 12,
    color: "#6B7280",
  },
  articleIcon: {
    fontSize: 32,
    alignSelf: "center",
  },
  videosSection: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  videoGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  videoCard: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  videoThumbnail: {
    fontSize: 48,
    marginBottom: 12,
  },
  videoTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: "#1F2937",
    textAlign: "center",
    marginBottom: 4,
  },
  videoDuration: {
    fontSize: 12,
    color: "#6B7280",
  },
  reminderSection: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  reminderCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  reminderIcon: {
    fontSize: 32,
    marginRight: 16,
  },
  reminderContent: {
    flex: 1,
  },
  reminderTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 4,
  },
  reminderText: {
    fontSize: 14,
    color: "#6B7280",
    lineHeight: 20,
  },
})

export default HealthScreen
