import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Linking } from "react-native"
import Header from "../components/Header"

const DoctorsScreen = () => {
  const doctors = [
    {
      id: "1",
      name: "Dr. MEENA P. SONONE (Dhole)",
      position: "Consultant Chest Physician, Intensivist and Diabetologist",
      qualifications: [
        "M.B.B.S. MGM College Indore (2003)",
        "D.T.C.D. PG Diploma in TB and Chest Diseases, MGM College Indore (2008)",
        "I.D.C.C.M. Indian Diploma, K.E.M. Hospital Pune (2010)",
        "F.I.D. Fellowship in Diabetes, Apollo Mediversity, Hyderabad (2016)",
      ],
      experience: "Ex Consultant: Apollo Hospitals, Nashik; Ashoka Medicover Nashik",
      registrationNumber: "2014/04/1628",
    },
    {
      id: "2",
      name: "Dr. PANKAJ A. SONONE",
      position: "Consultant Pathologist & Occupational Health Specialist",
      qualifications: [
        "M.B.B.S. Government Medical College, Nagpur (2004)",
        "D.C.P. PG Diploma, VM Govt. Medical College, Solapur (2010)",
        "M.H.A. Masterclass in Hospital Administration, Apollo Mediversity (2023)",
        "A.F.I.H. Asso. Fellow in Industrial Health, Regional Labour Inst. Kolkata (2024)",
      ],
      experience: "Ex Consultant: Deenanath Mangeshkar Hospital, Pune; Dr. Lal Path Labs, Delhi",
      registrationNumber: "2005/03/1594",
    },
  ]

  const handleSocialPress = (platform: string) => {
    const urls = {
      facebook: "https://facebook.com",
      twitter: "https://twitter.com",
      linkedin: "https://linkedin.com",
    }
    Linking.openURL(urls[platform] || urls.facebook)
  }

  return (
    <View style={styles.container}>
      <Header title="Our Doctors" showNotification={false} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Meet Our Expert Doctors</Text>
          <Text style={styles.headerSubtitle}>Qualified professionals dedicated to your health</Text>
        </View>

        {doctors.map((doctor) => (
          <View key={doctor.id} style={styles.doctorCard}>
            <View style={styles.doctorHeader}>
              <View style={styles.avatarContainer}>
                <Text style={styles.avatarText}>{doctor.name.split(" ")[1]?.charAt(0) || "D"}</Text>
              </View>
              <View style={styles.doctorInfo}>
                <Text style={styles.doctorName}>{doctor.name}</Text>
                <Text style={styles.doctorPosition}>{doctor.position}</Text>
                <Text style={styles.registrationNumber}>MMC Reg. No: {doctor.registrationNumber}</Text>
              </View>
            </View>

            <View style={styles.qualificationsSection}>
              <Text style={styles.sectionTitle}>Qualifications</Text>
              {doctor.qualifications.map((qualification, index) => (
                <View key={index} style={styles.qualificationItem}>
                  <Text style={styles.bulletPoint}>🎓</Text>
                  <Text style={styles.qualificationText}>{qualification}</Text>
                </View>
              ))}
            </View>

            <View style={styles.experienceSection}>
              <Text style={styles.sectionTitle}>Experience</Text>
              <Text style={styles.experienceText}>{doctor.experience}</Text>
            </View>

            <View style={styles.socialSection}>
              <Text style={styles.sectionTitle}>Connect</Text>
              <View style={styles.socialButtons}>
                <TouchableOpacity style={styles.socialButton} onPress={() => handleSocialPress("facebook")}>
                  <Text style={styles.socialIcon}>📘</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.socialButton} onPress={() => handleSocialPress("twitter")}>
                  <Text style={styles.socialIcon}>🐦</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.socialButton} onPress={() => handleSocialPress("linkedin")}>
                  <Text style={styles.socialIcon}>💼</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },
  header: {
    backgroundColor: "#1E3A8A",
    paddingHorizontal: 16,
    paddingVertical: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#FFFFFF",
    textAlign: "center",
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: "#FFFFFF",
    opacity: 0.9,
    textAlign: "center",
  },
  doctorCard: {
    backgroundColor: "#FFFFFF",
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  doctorHeader: {
    flexDirection: "row",
    marginBottom: 16,
  },
  avatarContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "#1E3A8A",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 16,
  },
  avatarText: {
    fontSize: 20,
    color: "#FFFFFF",
    fontWeight: "700",
  },
  doctorInfo: {
    flex: 1,
  },
  doctorName: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 4,
  },
  doctorPosition: {
    fontSize: 14,
    color: "#10B981",
    marginBottom: 4,
  },
  registrationNumber: {
    fontSize: 12,
    color: "#6B7280",
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 8,
  },
  qualificationsSection: {
    marginBottom: 16,
  },
  qualificationItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 4,
  },
  bulletPoint: {
    fontSize: 16,
    marginRight: 8,
    marginTop: 2,
  },
  qualificationText: {
    fontSize: 14,
    color: "#6B7280",
    flex: 1,
    lineHeight: 20,
  },
  experienceSection: {
    marginBottom: 16,
  },
  experienceText: {
    fontSize: 14,
    color: "#6B7280",
    lineHeight: 20,
  },
  socialSection: {
    borderTopWidth: 1,
    borderTopColor: "#E5E7EB",
    paddingTop: 16,
  },
  socialButtons: {
    flexDirection: "row",
    gap: 12,
  },
  socialButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#F3F4F6",
    justifyContent: "center",
    alignItems: "center",
  },
  socialIcon: {
    fontSize: 20,
  },
})

export default DoctorsScreen
