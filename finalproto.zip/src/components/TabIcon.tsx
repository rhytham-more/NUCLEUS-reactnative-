import type React from "react"
import { View, Text, StyleSheet } from "react-native"

interface TabIconProps {
  name: string
  color: string
}

const TabIcon: React.FC<TabIconProps> = ({ name, color }) => {
  const getIcon = () => {
    switch (name) {
      case "home":
        return "🏠"
      case "test":
        return "🧪"
      case "report":
        return "📄"
      case "health":
        return "❤️"
      case "contact":
        return "📞"
      default:
        return "📱"
    }
  }

  return (
    <View style={styles.container}>
      <Text style={[styles.icon, { color }]}>{getIcon()}</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
  },
  icon: {
    fontSize: 20,
  },
})

export default TabIcon
