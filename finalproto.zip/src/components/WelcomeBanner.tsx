"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { View, Text, StyleSheet, Dimensions, TouchableOpacity } from "react-native"
import { ScrollView } from "react-native"
import { colors, typography, spacing, borderRadius } from "../constants/theme"

const { width } = Dimensions.get("window")

interface BannerSlide {
  id: number
  title: string
  subtitle: string
  description: string
}

const slides: BannerSlide[] = [
  {
    id: 1,
    title: "Welcome to NUCLEUS Pathology Lab",
    subtitle: "Your Trusted Diagnostic Partner",
    description:
      "Book lab tests, schedule home collection, access reports, and more – your health journey begins here.",
  },
  {
    id: 2,
    title: "Monsoon Health Screening",
    subtitle: "Book Now for Special Discounts!",
    description: "Comprehensive health packages designed for the monsoon season. Stay healthy, stay protected.",
  },
]

interface WelcomeBannerProps {
  onBookTest?: () => void
  onViewReports?: () => void
}

const WelcomeBanner: React.FC<WelcomeBannerProps> = ({ onBookTest, onViewReports }) => {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <View style={styles.container}>
      <ScrollView
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={(event) => {
          const slideIndex = Math.round(event.nativeEvent.contentOffset.x / width)
          setCurrentSlide(slideIndex)
        }}
      >
        {slides.map((slide) => (
          <View key={slide.id} style={styles.slide}>
            <Text style={styles.title}>{slide.title}</Text>
            <Text style={styles.subtitle}>{slide.subtitle}</Text>
            <Text style={styles.description}>{slide.description}</Text>

            <View style={styles.buttonContainer}>
              <TouchableOpacity style={[styles.button, styles.primaryButton]} onPress={onBookTest}>
                <Text style={styles.primaryButtonText}>Book a Test</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.button, styles.secondaryButton]} onPress={onViewReports}>
                <Text style={styles.secondaryButtonText}>View Reports</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>

      <View style={styles.pagination}>
        {slides.map((_, index) => (
          <View key={index} style={[styles.dot, index === currentSlide ? styles.activeDot : styles.inactiveDot]} />
        ))}
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.primary,
    borderBottomLeftRadius: borderRadius.xl,
    borderBottomRightRadius: borderRadius.xl,
    marginBottom: spacing.md,
  },
  slide: {
    width,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xl,
  },
  title: {
    ...typography.h1,
    color: colors.surface,
    marginBottom: spacing.sm,
  },
  subtitle: {
    ...typography.h2,
    color: colors.surface,
    opacity: 0.9,
    marginBottom: spacing.sm,
  },
  description: {
    ...typography.body,
    color: colors.surface,
    opacity: 0.8,
    lineHeight: 24,
    marginBottom: spacing.lg,
  },
  buttonContainer: {
    flexDirection: "row",
    gap: spacing.sm,
  },
  button: {
    flex: 1,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: "center",
    minHeight: 48,
    justifyContent: "center",
  },
  primaryButton: {
    backgroundColor: colors.surface,
  },
  secondaryButton: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    borderWidth: 1,
    borderColor: colors.surface,
  },
  primaryButtonText: {
    ...typography.body,
    color: colors.primary,
    fontWeight: "600",
  },
  secondaryButtonText: {
    ...typography.body,
    color: colors.surface,
    fontWeight: "600",
  },
  pagination: {
    flexDirection: "row",
    justifyContent: "center",
    paddingBottom: spacing.md,
    gap: spacing.xs,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  activeDot: {
    backgroundColor: colors.surface,
  },
  inactiveDot: {
    backgroundColor: "rgba(255, 255, 255, 0.4)",
  },
})

export default WelcomeBanner
