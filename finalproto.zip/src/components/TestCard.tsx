import type React from "react"
import { View, Text, TouchableOpacity, StyleSheet } from "react-native"
import Icon from "react-native-vector-icons/MaterialIcons"
import { colors, typography, spacing, borderRadius } from "../constants/theme"

interface Test {
  id: string
  name: string
  description: string
  price: number
  originalPrice?: number
  duration: string
  preparation: string
  isPopular?: boolean
  fastingRequired?: boolean
}

interface TestCardProps {
  test: Test
  onPress: () => void
}

const TestCard: React.FC<TestCardProps> = ({ test, onPress }) => {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <Text style={styles.title}>{test.name}</Text>
          {test.isPopular && (
            <View style={styles.popularBadge}>
              <Text style={styles.popularText}>Popular</Text>
            </View>
          )}
        </View>
        <View style={styles.priceContainer}>
          <Text style={styles.price}>₹{test.price}</Text>
          {test.originalPrice && <Text style={styles.originalPrice}>₹{test.originalPrice}</Text>}
        </View>
      </View>

      <Text style={styles.description}>{test.description}</Text>

      <View style={styles.infoContainer}>
        <View style={styles.infoItem}>
          <Icon name="schedule" size={16} color={colors.textSecondary} />
          <Text style={styles.infoText}>{test.duration}</Text>
        </View>
        <View style={styles.infoItem}>
          <Icon name={test.fastingRequired ? "no-food" : "restaurant"} size={16} color={colors.textSecondary} />
          <Text style={styles.infoText}>{test.preparation}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.bookButton} onPress={onPress}>
        <Text style={styles.bookButtonText}>Book Now</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    shadowColor: colors.shadow,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: spacing.sm,
  },
  titleContainer: {
    flex: 1,
    marginRight: spacing.sm,
  },
  title: {
    ...typography.body,
    fontWeight: "600",
    color: colors.text,
    marginBottom: spacing.xs,
  },
  popularBadge: {
    backgroundColor: colors.warning,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: borderRadius.sm,
    alignSelf: "flex-start",
  },
  popularText: {
    ...typography.caption,
    color: colors.surface,
    fontWeight: "600",
  },
  priceContainer: {
    alignItems: "flex-end",
  },
  price: {
    ...typography.body,
    fontWeight: "700",
    color: colors.secondary,
  },
  originalPrice: {
    ...typography.caption,
    color: colors.textSecondary,
    textDecorationLine: "line-through",
  },
  description: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    lineHeight: 20,
    marginBottom: spacing.sm,
  },
  infoContainer: {
    marginBottom: spacing.md,
  },
  infoItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.xs,
  },
  infoText: {
    ...typography.caption,
    color: colors.textSecondary,
    marginLeft: spacing.xs,
  },
  bookButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.sm,
    alignItems: "center",
  },
  bookButtonText: {
    ...typography.bodySmall,
    color: colors.surface,
    fontWeight: "600",
  },
})

export default TestCard
