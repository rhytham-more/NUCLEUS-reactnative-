"use client"

import type React from "react"
import { createContext, useContext, useReducer, type ReactNode } from "react"

interface User {
  id: string
  name: string
  email: string
  phone: string
}

interface BookingData {
  patientInfo?: any
  selectedTests?: any[]
  appointmentDate?: string
  appointmentTime?: string
  collectionAddress?: any
}

interface AppState {
  user: User | null
  isAuthenticated: boolean
  bookingData: BookingData
  notifications: any[]
}

type AppAction =
  | { type: "SET_USER"; payload: User }
  | { type: "LOGOUT" }
  | { type: "UPDATE_BOOKING_DATA"; payload: Partial<BookingData> }
  | { type: "CLEAR_BOOKING_DATA" }
  | { type: "ADD_NOTIFICATION"; payload: any }

const initialState: AppState = {
  user: null,
  isAuthenticated: false,
  bookingData: {},
  notifications: [],
}

const AppContext = createContext<{
  state: AppState
  dispatch: React.Dispatch<AppAction>
} | null>(null)

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case "SET_USER":
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
      }
    case "LOGOUT":
      return {
        ...state,
        user: null,
        isAuthenticated: false,
      }
    case "UPDATE_BOOKING_DATA":
      return {
        ...state,
        bookingData: { ...state.bookingData, ...action.payload },
      }
    case "CLEAR_BOOKING_DATA":
      return {
        ...state,
        bookingData: {},
      }
    case "ADD_NOTIFICATION":
      return {
        ...state,
        notifications: [action.payload, ...state.notifications],
      }
    default:
      return state
  }
}

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState)

  return <AppContext.Provider value={{ state, dispatch }}>{children}</AppContext.Provider>
}

export const useAppContext = () => {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useAppContext must be used within AppProvider")
  }
  return context
}
