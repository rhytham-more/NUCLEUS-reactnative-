import { DefaultTheme } from "react-native-paper"

export const colors = {
  primary: "#1E3A8A", // Deep Blue
  secondary: "#10B981", // Emerald Green
  surface: "#FFFFFF", // White
  background: "#F3F4F6", // Light Gray
  text: "#1F2937",
  textSecondary: "#6B7280",
  error: "#EF4444",
  warning: "#F59E0B",
  success: "#10B981",
  border: "#E5E7EB",
  shadow: "#00000020",
}

export const typography = {
  h1: {
    fontSize: 24,
    fontWeight: "700" as const,
    fontFamily: "Inter-Bold",
  },
  h2: {
    fontSize: 20,
    fontWeight: "600" as const,
    fontFamily: "Inter-SemiBold",
  },
  body: {
    fontSize: 16,
    fontWeight: "400" as const,
    fontFamily: "Inter-Regular",
  },
  bodySmall: {
    fontSize: 14,
    fontWeight: "400" as const,
    fontFamily: "Inter-Regular",
  },
  caption: {
    fontSize: 12,
    fontWeight: "400" as const,
    fontFamily: "Inter-Regular",
  },
}

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
}

export const borderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
}

export const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    ...colors,
  },
  typography,
  spacing,
  borderRadius,
}
