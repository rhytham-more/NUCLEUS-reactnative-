import { createNativeStackNavigator } from "@react-navigation/native-stack"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import Icon from "react-native-vector-icons/MaterialIcons"
import { colors } from "../constants/theme"

// Screens
import HomeScreen from "../screens/HomeScreen"
import BookTestScreen from "../screens/BookTestScreen"
import ReportsScreen from "../screens/ReportsScreen"
import HealthScreen from "../screens/HealthScreen"
import ContactScreen from "../screens/ContactScreen"
import AboutScreen from "../screens/AboutScreen"
import DoctorsScreen from "../screens/DoctorsScreen"
import SampleCollectionScreen from "../screens/SampleCollectionScreen"
import BookingFlowScreen from "../screens/BookingFlowScreen"
import LabDetailsScreen from "../screens/LabDetailsScreen"

export type RootStackParamList = {
  MainTabs: undefined
  About: undefined
  Doctors: undefined
  SampleCollection: undefined
  BookingFlow: { step?: number }
  LabDetails: undefined
}

export type TabParamList = {
  Home: undefined
  BookTest: undefined
  Reports: undefined
  Health: undefined
  Contact: undefined
}

const Stack = createNativeStackNavigator<RootStackParamList>()
const Tab = createBottomTabNavigator<TabParamList>()

const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: string

          switch (route.name) {
            case "Home":
              iconName = "home"
              break
            case "BookTest":
              iconName = "science"
              break
            case "Reports":
              iconName = "description"
              break
            case "Health":
              iconName = "favorite"
              break
            case "Contact":
              iconName = "phone"
              break
            default:
              iconName = "home"
          }

          return <Icon name={iconName} size={size} color={color} />
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          paddingBottom: 8,
          paddingTop: 8,
          height: 60,
        },
        headerShown: false,
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ tabBarLabel: "Home" }} />
      <Tab.Screen name="BookTest" component={BookTestScreen} options={{ tabBarLabel: "Book Test" }} />
      <Tab.Screen name="Reports" component={ReportsScreen} options={{ tabBarLabel: "Reports" }} />
      <Tab.Screen name="Health" component={HealthScreen} options={{ tabBarLabel: "Health" }} />
      <Tab.Screen name="Contact" component={ContactScreen} options={{ tabBarLabel: "Contact" }} />
    </Tab.Navigator>
  )
}

const RootNavigator = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.surface,
        },
        headerTintColor: colors.primary,
        headerTitleStyle: {
          fontWeight: "600",
          fontSize: 18,
        },
      }}
    >
      <Stack.Screen name="MainTabs" component={TabNavigator} options={{ headerShown: false }} />
      <Stack.Screen name="About" component={AboutScreen} options={{ title: "About NUCLEUS" }} />
      <Stack.Screen name="Doctors" component={DoctorsScreen} options={{ title: "Our Doctors" }} />
      <Stack.Screen
        name="SampleCollection"
        component={SampleCollectionScreen}
        options={{ title: "Sample Collection" }}
      />
      <Stack.Screen name="BookingFlow" component={BookingFlowScreen} options={{ title: "Book Test" }} />
      <Stack.Screen name="LabDetails" component={LabDetailsScreen} options={{ title: "Lab Details" }} />
    </Stack.Navigator>
  )
}

export default RootNavigator
