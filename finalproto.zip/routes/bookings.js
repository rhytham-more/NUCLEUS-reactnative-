const express = require("express")
const Booking = require("../models/Booking")
const Test = require("../models/Test")
const { protect } = require("../middleware/auth")
const { sendEmail } = require("../utils/sendEmail")
const { sendSMS } = require("../utils/sendSMS")

const router = express.Router()

// @desc    Create booking
// @route   POST /api/bookings
// @access  Private
router.post("/", protect, async (req, res) => {
  try {
    const { tests, bookingType, appointmentDate, appointmentTime, collectionAddress, notes } = req.body

    // Validate tests and calculate total
    let totalAmount = 0
    const testDetails = []

    for (const testItem of tests) {
      const test = await Test.findById(testItem.test)
      if (!test) {
        return res.status(404).json({
          success: false,
          message: `Test not found: ${testItem.test}`,
        })
      }

      const quantity = testItem.quantity || 1
      const price = test.discountedPrice || test.price
      totalAmount += price * quantity

      testDetails.push({
        test: test._id,
        quantity,
      })
    }

    // Create booking
    const booking = await Booking.create({
      patient: req.user.id,
      tests: testDetails,
      totalAmount,
      finalAmount: totalAmount, // Apply discounts here if needed
      bookingType,
      appointmentDate,
      appointmentTime,
      collectionAddress: bookingType === "home_collection" ? collectionAddress : undefined,
      notes,
    })

    // Populate booking details
    await booking.populate([
      { path: "patient", select: "name email phone" },
      { path: "tests.test", select: "name code price" },
    ])

    // Send confirmation email and SMS
    try {
      const emailContent = `
        Dear ${booking.patient.name},
        
        Your booking has been confirmed!
        
        Booking ID: ${booking.bookingId}
        Date: ${new Date(booking.appointmentDate).toLocaleDateString()}
        Time: ${booking.appointmentTime}
        Type: ${booking.bookingType === "home_collection" ? "Home Collection" : "Lab Visit"}
        Total Amount: ₹${booking.finalAmount}
        
        We will contact you shortly with further details.
        
        Thank you for choosing Nucleus Lab!
      `

      await sendEmail({
        email: booking.patient.email,
        subject: "Booking Confirmation - Nucleus Lab",
        message: emailContent,
      })

      await sendSMS({
        phone: booking.patient.phone,
        message: `Booking confirmed! ID: ${booking.bookingId}. Date: ${new Date(booking.appointmentDate).toLocaleDateString()} at ${booking.appointmentTime}. Amount: ₹${booking.finalAmount}`,
      })
    } catch (error) {
      console.error("Notification sending failed:", error)
    }

    res.status(201).json({
      success: true,
      message: "Booking created successfully",
      data: booking,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while creating booking",
    })
  }
})

// @desc    Get user bookings
// @route   GET /api/bookings
// @access  Private
router.get("/", protect, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query

    const query = { patient: req.user.id }

    if (status) {
      query.status = status
    }

    const bookings = await Booking.find(query)
      .populate([
        { path: "tests.test", select: "name code price category" },
        { path: "assignedPhlebotomist", select: "name phone" },
      ])
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)

    const total = await Booking.countDocuments(query)

    res.status(200).json({
      success: true,
      count: bookings.length,
      total,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(total / limit),
      },
      data: bookings,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while fetching bookings",
    })
  }
})

// @desc    Get single booking
// @route   GET /api/bookings/:id
// @access  Private
router.get("/:id", protect, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      _id: req.params.id,
      patient: req.user.id,
    }).populate([
      { path: "patient", select: "name email phone" },
      { path: "tests.test", select: "name code price category description" },
      { path: "assignedPhlebotomist", select: "name phone" },
    ])

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      })
    }

    res.status(200).json({
      success: true,
      data: booking,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while fetching booking",
    })
  }
})

// @desc    Cancel booking
// @route   PUT /api/bookings/:id/cancel
// @access  Private
router.put("/:id/cancel", protect, async (req, res) => {
  try {
    const { cancellationReason } = req.body

    const booking = await Booking.findOne({
      _id: req.params.id,
      patient: req.user.id,
    })

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: "Booking not found",
      })
    }

    if (booking.status === "cancelled") {
      return res.status(400).json({
        success: false,
        message: "Booking is already cancelled",
      })
    }

    if (["sample_collected", "processing", "completed"].includes(booking.status)) {
      return res.status(400).json({
        success: false,
        message: "Cannot cancel booking at this stage",
      })
    }

    booking.status = "cancelled"
    booking.cancellationReason = cancellationReason

    // Handle refund logic here
    if (booking.paymentStatus === "paid") {
      booking.refundStatus = "pending"
      booking.refundAmount = booking.finalAmount
    }

    await booking.save()

    res.status(200).json({
      success: true,
      message: "Booking cancelled successfully",
      data: booking,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while cancelling booking",
    })
  }
})

// @desc    Get available time slots
// @route   GET /api/bookings/slots/:date
// @access  Public
router.get("/slots/:date", async (req, res) => {
  try {
    const { date } = req.params
    const { type = "lab_visit" } = req.query

    // Define available slots based on type
    const labSlots = [
      "08:00",
      "08:30",
      "09:00",
      "09:30",
      "10:00",
      "10:30",
      "11:00",
      "11:30",
      "12:00",
      "14:00",
      "14:30",
      "15:00",
      "15:30",
      "16:00",
      "16:30",
      "17:00",
      "17:30",
      "18:00",
    ]

    const homeSlots = [
      "07:00",
      "07:30",
      "08:00",
      "08:30",
      "09:00",
      "09:30",
      "10:00",
      "10:30",
      "11:00",
      "11:30",
      "12:00",
      "16:00",
      "16:30",
      "17:00",
      "17:30",
      "18:00",
      "18:30",
      "19:00",
    ]

    const availableSlots = type === "home_collection" ? homeSlots : labSlots

    // Get booked slots for the date
    const bookedSlots = await Booking.find({
      appointmentDate: new Date(date),
      status: { $nin: ["cancelled"] },
    }).distinct("appointmentTime")

    // Filter out booked slots
    const freeSlots = availableSlots.filter((slot) => !bookedSlots.includes(slot))

    res.status(200).json({
      success: true,
      data: {
        date,
        type,
        availableSlots: freeSlots,
        bookedSlots,
      },
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while fetching time slots",
    })
  }
})

module.exports = router
