const express = require("express")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const crypto = require("crypto")
const User = require("../models/User")
const { protect } = require("../middleware/auth")
const { sendEmail } = require("../utils/sendEmail")
const { sendSMS } = require("../utils/sendSMS")

const router = express.Router()

// @desc    Register user
// @route   POST /api/auth/register
// @access  Public
router.post("/register", async (req, res) => {
  try {
    const { name, email, phone, password } = req.body

    // Check if user exists
    const existingUser = await User.findOne({
      $or: [{ email }, { phone }],
    })

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: "User already exists with this email or phone",
      })
    }

    // Create user
    const user = await User.create({
      name,
      email,
      phone,
      password,
    })

    // Generate verification token
    const verificationToken = crypto.randomBytes(20).toString("hex")
    user.verificationToken = verificationToken
    await user.save()

    // Send verification email
    const verificationUrl = `${process.env.FRONTEND_URL}/verify-email/${verificationToken}`

    try {
      await sendEmail({
        email: user.email,
        subject: "Email Verification - Nucleus Lab",
        message: `Please click on this link to verify your email: ${verificationUrl}`,
      })
    } catch (error) {
      console.error("Email sending failed:", error)
    }

    // Generate token
    const token = user.getSignedJwtToken()

    res.status(201).json({
      success: true,
      message: "User registered successfully. Please verify your email.",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        isVerified: user.isVerified,
      },
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error during registration",
    })
  }
})

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body

    // Validate email and password
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Please provide email and password",
      })
    }

    // Check for user
    const user = await User.findOne({ email }).select("+password")

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials",
      })
    }

    // Check if password matches
    const isMatch = await user.comparePassword(password)

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials",
      })
    }

    // Update last login
    user.lastLogin = new Date()
    await user.save()

    // Generate token
    const token = user.getSignedJwtToken()

    res.status(200).json({
      success: true,
      message: "Login successful",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isVerified: user.isVerified,
      },
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error during login",
    })
  }
})

// @desc    Get current logged in user
// @route   GET /api/auth/me
// @access  Private
router.get("/me", protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate("familyMembers")

    res.status(200).json({
      success: true,
      user,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error",
    })
  }
})

// @desc    Verify email
// @route   GET /api/auth/verify-email/:token
// @access  Public
router.get("/verify-email/:token", async (req, res) => {
  try {
    const user = await User.findOne({
      verificationToken: req.params.token,
    })

    if (!user) {
      return res.status(400).json({
        success: false,
        message: "Invalid verification token",
      })
    }

    user.isVerified = true
    user.verificationToken = undefined
    await user.save()

    res.status(200).json({
      success: true,
      message: "Email verified successfully",
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error during verification",
    })
  }
})

// @desc    Send OTP for login
// @route   POST /api/auth/send-otp
// @access  Public
router.post("/send-otp", async (req, res) => {
  try {
    const { phone } = req.body

    if (!phone) {
      return res.status(400).json({
        success: false,
        message: "Phone number is required",
      })
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString()

    // Store OTP in cache/database (implement your preferred method)
    // For demo purposes, we'll use a simple in-memory store
    global.otpStore = global.otpStore || {}
    global.otpStore[phone] = {
      otp,
      expires: Date.now() + 5 * 60 * 1000, // 5 minutes
    }

    // Send OTP via SMS
    try {
      await sendSMS({
        phone,
        message: `Your Nucleus Lab OTP is: ${otp}. Valid for 5 minutes.`,
      })
    } catch (error) {
      console.error("SMS sending failed:", error)
    }

    res.status(200).json({
      success: true,
      message: "OTP sent successfully",
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while sending OTP",
    })
  }
})

// @desc    Verify OTP and login
// @route   POST /api/auth/verify-otp
// @access  Public
router.post("/verify-otp", async (req, res) => {
  try {
    const { phone, otp } = req.body

    if (!phone || !otp) {
      return res.status(400).json({
        success: false,
        message: "Phone number and OTP are required",
      })
    }

    // Check OTP
    const storedOTP = global.otpStore?.[phone]

    if (!storedOTP || storedOTP.expires < Date.now()) {
      return res.status(400).json({
        success: false,
        message: "OTP expired or invalid",
      })
    }

    if (storedOTP.otp !== otp) {
      return res.status(400).json({
        success: false,
        message: "Invalid OTP",
      })
    }

    // Find or create user
    const user = await User.findOne({ phone })

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found. Please register first.",
      })
    }

    // Clear OTP
    delete global.otpStore[phone]

    // Update last login
    user.lastLogin = new Date()
    await user.save()

    // Generate token
    const token = user.getSignedJwtToken()

    res.status(200).json({
      success: true,
      message: "OTP verified successfully",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isVerified: user.isVerified,
      },
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error during OTP verification",
    })
  }
})

module.exports = router
