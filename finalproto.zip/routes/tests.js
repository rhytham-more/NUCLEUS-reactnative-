const express = require("express")
const Test = require("../models/Test")
const { protect, authorize } = require("../middleware/auth")

const router = express.Router()

// @desc    Get all tests
// @route   GET /api/tests
// @access  Public
router.get("/", async (req, res) => {
  try {
    const { category, popular, homeCollection, minPrice, maxPrice, search, page = 1, limit = 10 } = req.query

    // Build query
    const query = { isActive: true }

    if (category) {
      query.category = category
    }

    if (popular === "true") {
      query.isPopular = true
    }

    if (homeCollection === "true") {
      query.homeCollectionAvailable = true
    }

    if (minPrice || maxPrice) {
      query.price = {}
      if (minPrice) query.price.$gte = Number(minPrice)
      if (maxPrice) query.price.$lte = Number(maxPrice)
    }

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
        { code: { $regex: search, $options: "i" } },
      ]
    }

    // Execute query with pagination
    const tests = await Test.find(query)
      .sort({ isPopular: -1, name: 1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)

    const total = await Test.countDocuments(query)

    res.status(200).json({
      success: true,
      count: tests.length,
      total,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(total / limit),
      },
      data: tests,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while fetching tests",
    })
  }
})

// @desc    Get single test
// @route   GET /api/tests/:id
// @access  Public
router.get("/:id", async (req, res) => {
  try {
    const test = await Test.findById(req.params.id)

    if (!test) {
      return res.status(404).json({
        success: false,
        message: "Test not found",
      })
    }

    res.status(200).json({
      success: true,
      data: test,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while fetching test",
    })
  }
})

// @desc    Get popular tests
// @route   GET /api/tests/popular/list
// @access  Public
router.get("/popular/list", async (req, res) => {
  try {
    const tests = await Test.find({
      isActive: true,
      isPopular: true,
    })
      .sort({ name: 1 })
      .limit(10)

    res.status(200).json({
      success: true,
      count: tests.length,
      data: tests,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while fetching popular tests",
    })
  }
})

// @desc    Get test categories
// @route   GET /api/tests/categories/list
// @access  Public
router.get("/categories/list", async (req, res) => {
  try {
    const categories = await Test.distinct("category", { isActive: true })

    res.status(200).json({
      success: true,
      data: categories,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while fetching categories",
    })
  }
})

// @desc    Create test
// @route   POST /api/tests
// @access  Private (Admin only)
router.post("/", protect, authorize("admin"), async (req, res) => {
  try {
    const test = await Test.create(req.body)

    res.status(201).json({
      success: true,
      message: "Test created successfully",
      data: test,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while creating test",
    })
  }
})

// @desc    Update test
// @route   PUT /api/tests/:id
// @access  Private (Admin only)
router.put("/:id", protect, authorize("admin"), async (req, res) => {
  try {
    const test = await Test.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    })

    if (!test) {
      return res.status(404).json({
        success: false,
        message: "Test not found",
      })
    }

    res.status(200).json({
      success: true,
      message: "Test updated successfully",
      data: test,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while updating test",
    })
  }
})

// @desc    Delete test
// @route   DELETE /api/tests/:id
// @access  Private (Admin only)
router.delete("/:id", protect, authorize("admin"), async (req, res) => {
  try {
    const test = await Test.findById(req.params.id)

    if (!test) {
      return res.status(404).json({
        success: false,
        message: "Test not found",
      })
    }

    // Soft delete - mark as inactive
    test.isActive = false
    await test.save()

    res.status(200).json({
      success: true,
      message: "Test deleted successfully",
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({
      success: false,
      message: "Server error while deleting test",
    })
  }
})

module.exports = router
