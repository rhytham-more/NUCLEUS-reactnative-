import { Card, CardContent } from "@/components/ui/card"
import { Heart, Target } from "lucide-react"

export default function AboutSection() {
  return (
    <div className="px-4 mb-6">
      <h2 className="text-lg font-bold text-slate-800 mb-4">About NUCLEUS</h2>

      <Card className="mb-4 border-slate-100 shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 gradient-red rounded-xl flex items-center justify-center flex-shrink-0 shadow-md">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-800 mb-2">Expert Diagnostics, Compassionate Care</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                NUCLEUS is dedicated to reliable, affordable, and accessible diagnostic services powered by technology
                and humanity.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-100 shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 gradient-blue rounded-xl flex items-center justify-center flex-shrink-0 shadow-md">
              <Target className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-800 mb-2">Our Mission</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Making quality healthcare accessible and convenient for all.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
