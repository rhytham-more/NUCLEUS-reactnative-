import { View, Text, StyleSheet, TouchableOpacity } from "react-native"
import { useNavigation } from "@react-navigation/native"
import { Ionicons } from "@expo/vector-icons"

const BottomTabBar = () => {
  const navigation = useNavigation()

  const tabs = [
    { name: "Home", icon: "home", screen: "Home" },
    { name: "Services", icon: "medical", screen: "Services" },
    { name: "Doctors", icon: "people", screen: "Doctors" },
    { name: "Contact", icon: "call", screen: "Contact" },
  ]

  return (
    <View style={styles.container}>
      {tabs.map((tab) => (
        <TouchableOpacity key={tab.name} style={styles.tab} onPress={() => navigation.navigate(tab.screen)}>
          <Ionicons name={tab.icon} size={24} color="#2196F3" />
          <Text style={styles.tabText}>{tab.name}</Text>
        </TouchableOpacity>
      ))}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: "#ffffff",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: "#f0f0f0",
  },
  tab: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  tabText: {
    fontSize: 12,
    marginTop: 4,
    color: "#2196F3",
  },
})

export default BottomTabBar
