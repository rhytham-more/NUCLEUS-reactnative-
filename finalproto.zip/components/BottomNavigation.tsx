"use client"

import { Home, TestTube, FileText, Heart, Phone } from "lucide-react"

interface BottomNavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export default function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: "home", label: "Home", icon: Home },
    { id: "book-test", label: "Book Test", icon: TestTube },
    { id: "reports", label: "Reports", icon: FileText },
    { id: "health", label: "Health", icon: Heart },
    { id: "contact", label: "Contact", icon: Phone },
  ]

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white/90 backdrop-blur-md border-t border-slate-200/50 shadow-xl">
      <div className="flex">
        {tabs.map((tab) => {
          const IconComponent = tab.icon
          const isActive = activeTab === tab.id

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex-1 py-3 px-2 flex flex-col items-center space-y-1 transition-all btn-scale ${
                isActive ? "text-red-500" : "text-slate-500 hover:text-slate-700"
              }`}
            >
              <div className={`p-1 rounded-lg transition-all ${isActive ? "bg-red-50 shadow-sm" : ""}`}>
                <IconComponent className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
