import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp, Calendar } from "lucide-react"

interface HealthFeedProps {
  expanded?: boolean
}

export default function HealthFeed({ expanded = false }: HealthFeedProps) {
  const articles = [
    {
      id: 1,
      title: "Why Regular Checkups Matter",
      description: "Learn about the importance of preventive healthcare",
      readTime: "3 min read",
    },
    {
      id: 2,
      title: "Tips for Healthy Blood Sugar",
      description: "Simple lifestyle changes for better glucose control",
      readTime: "5 min read",
    },
    {
      id: 3,
      title: "Seasonal Disease Updates",
      description: "Stay protected during monsoon season",
      readTime: "4 min read",
    },
  ]

  return (
    <div className="px-4 mb-6">
      <h2 className="text-lg font-bold text-slate-800 mb-4">Health & Wellness</h2>

      <Card className="mb-4 gradient-blue border-0 shadow-xl">
        <CardContent className="p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold mb-1">Daily Health Tip</h3>
              <p className="text-blue-100 text-sm">Drink water—8–10 glasses a day!</p>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <span className="text-2xl">💧</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-4 gradient-green border-0 shadow-xl">
        <CardContent className="p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold mb-1">Wellness Reminder</h3>
              <p className="text-green-100 text-sm">Next wellness checkup recommended: September 2025</p>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Calendar className="w-6 h-6" />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3 mb-4">
        {(expanded ? articles : articles.slice(0, 2)).map((article) => (
          <Card key={article.id} className="border-slate-100 card-hover shadow-lg">
            <CardContent className="p-0">
              <div className="flex">
                <div className="w-20 h-20 bg-gradient-to-br from-red-100 to-pink-100 rounded-l-lg flex items-center justify-center">
                  <span className="text-2xl">📄</span>
                </div>
                <div className="p-3 flex-1">
                  <h3 className="font-semibold text-sm text-slate-800 mb-1">{article.title}</h3>
                  <p className="text-slate-600 text-xs mb-2">{article.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-xs">{article.readTime}</span>
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
