import { Facebook, Instagram, Linkedin } from "lucide-react"

export default function Footer() {
  const quickLinks = ["Home", "Book Test", "Reports", "Health", "Profile", "About Lab"]

  return (
    <div className="px-4 py-6 bg-slate-100 rounded-t-3xl mt-8 shadow-xl">
      <div className="text-center mb-6">
        <h3 className="font-bold text-slate-800 mb-2">NUCLEUS Pathology Laboratory</h3>
        <p className="text-slate-600 text-sm">
          Comprehensive diagnostic solutions with cutting-edge equipment, certified staff, and fast turnaround times.
        </p>
      </div>

      <div className="mb-6">
        <h4 className="font-semibold text-slate-800 mb-3 text-sm">Our Services</h4>
        <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
          <span>Blood Testing</span>
          <span>Health Checkup Packages</span>
          <span>Diagnostic Services</span>
          <span>Home Sample Collection</span>
          <span>Biochemical Tests</span>
          <span>Pathology Tests</span>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="font-semibold text-slate-800 mb-3 text-sm">Facilities Highlights</h4>
        <div className="space-y-1 text-xs text-slate-600">
          <p>• NABL-equipment and accredited processes</p>
          <p>• Safe, sanitized sample collection</p>
          <p>• 24/7 digital report access</p>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="font-semibold text-slate-800 mb-3 text-sm">Quick Links</h4>
        <div className="flex flex-wrap gap-2">
          {quickLinks.map((link, index) => (
            <button key={index} className="text-xs text-slate-600 hover:text-red-500 transition-colors btn-scale">
              {link}
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-center space-x-4 mb-6">
        <button className="p-2 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors btn-scale shadow-sm">
          <Facebook className="w-5 h-5 text-blue-600" />
        </button>
        <button className="p-2 bg-pink-50 rounded-lg hover:bg-pink-100 transition-colors btn-scale shadow-sm">
          <Instagram className="w-5 h-5 text-pink-600" />
        </button>
        <button className="p-2 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors btn-scale shadow-sm">
          <Linkedin className="w-5 h-5 text-blue-700" />
        </button>
      </div>

      <div className="text-center space-y-2 text-xs text-slate-500">
        <div className="flex justify-center space-x-4">
          <button className="hover:text-slate-700 btn-scale">Privacy Policy</button>
          <button className="hover:text-slate-700 btn-scale">Terms of Service</button>
        </div>
        <p>© 2024 NUCLEUS Pathology Laboratory. All rights reserved.</p>
      </div>
    </div>
  )
}
