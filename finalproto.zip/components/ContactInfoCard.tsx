import type React from "react"
import { View, Text, StyleSheet, TouchableOpacity, Linking } from "react-native"
import { Ionicons } from "@expo/vector-icons"

interface ContactInfoCardProps {
  phoneNumbers: string[]
  address: string
  email: string
}

const ContactInfoCard: React.FC<ContactInfoCardProps> = ({ phoneNumbers, address, email }) => {
  const handlePhoneCall = (phoneNumber: string) => {
    Linking.openURL(`tel:${phoneNumber}`)
  }

  const handleEmail = () => {
    Linking.openURL(`mailto:${email}`)
  }

  const handleMap = () => {
    Linking.openURL(`https://maps.google.com/?q=${encodeURIComponent(address)}`)
  }

  return (
    <View style={styles.card}>
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Ionicons name="call" size={20} color="#2196F3" />
          <Text style={styles.sectionTitle}>Phone</Text>
        </View>
        {phoneNumbers.map((phone, index) => (
          <TouchableOpacity key={index} onPress={() => handlePhoneCall(phone)} style={styles.contactItem}>
            <Text style={styles.contactText}>{phone}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.divider} />

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Ionicons name="location" size={20} color="#2196F3" />
          <Text style={styles.sectionTitle}>Address</Text>
        </View>
        <TouchableOpacity onPress={handleMap} style={styles.contactItem}>
          <Text style={styles.contactText}>{address}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.divider} />

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Ionicons name="mail" size={20} color="#2196F3" />
          <Text style={styles.sectionTitle}>Email</Text>
        </View>
        <TouchableOpacity onPress={handleEmail} style={styles.contactItem}>
          <Text style={styles.contactText}>{email}</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  section: {
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333333",
    marginLeft: 8,
  },
  contactItem: {
    paddingVertical: 4,
  },
  contactText: {
    fontSize: 15,
    color: "#666666",
  },
  divider: {
    height: 1,
    backgroundColor: "#f0f0f0",
    marginVertical: 8,
  },
})

export default ContactInfoCard
