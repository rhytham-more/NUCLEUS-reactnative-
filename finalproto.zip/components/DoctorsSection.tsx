import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, MapPin, Facebook, Twitter, Linkedin } from "lucide-react"

export default function DoctorsSection() {
  const doctors = [
    {
      name: "Dr. MEENA P. SONONE (Dhole)",
      position: "Consultant Chest Physician, Intensivist and Diabetologist",
      qualifications: [
        "M.B.B.S. MGM College Indore (2003)",
        "D.T.C.D. PG Diploma in TB and Chest Diseases, MGM College Indore (2008)",
        "I.D.C.C.M. Indian Diploma, K.E.M. Hospital Pune (2010)",
        "F.I.D. Fellowship in Diabetes, Apollo Mediversity, Hyderabad (2016)",
      ],
      mmcReg: "2014/04/1628",
      experience: "Ex Consultant: Apollo Hospitals, Nashik; Ashoka Medicover Nashik",
    },
    {
      name: "Dr. PANKAJ A. SONONE",
      position: "Consultant Pathologist & Occupational Health Specialist",
      qualifications: [
        "M.B.B.S. Government Medical College, Nagpur (2004)",
        "D.C.P. PG Diploma, VM Govt. Medical College, Solapur (2010)",
        "M.H.A. Masterclass in Hospital Administration, Apollo Mediversity (2023)",
        "A.F.I.H. Asso. Fellow in Industrial Health, Regional Labour Inst. Kolkata (2024)",
      ],
      mmcReg: "2005/03/1594",
      experience: "Ex Consultant: Deenanath Mangeshkar Hospital, Pune; Dr. Lal Path Labs, Delhi",
    },
  ]

  return (
    <div className="px-4 mb-6">
      <h2 className="text-lg font-bold text-slate-800 mb-4">Our Doctors</h2>

      <div className="space-y-4">
        {doctors.map((doctor, index) => (
          <Card key={index} className="border-slate-100 overflow-hidden shadow-xl">
            <CardContent className="p-0">
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 rounded-full gradient-blue flex items-center justify-center flex-shrink-0 shadow-lg">
                    <span className="text-white text-2xl font-bold">{doctor.name.split(" ")[1]?.charAt(0) || "D"}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-slate-800 text-sm mb-1">{doctor.name}</h3>
                    <p className="text-red-600 font-medium text-xs mb-2">{doctor.position}</p>
                    <Badge className="bg-blue-100 text-blue-600 text-xs border-blue-200">MMC: {doctor.mmcReg}</Badge>
                  </div>
                </div>
              </div>

              <div className="p-4">
                <div className="mb-3">
                  <h4 className="font-semibold text-slate-800 mb-2 flex items-center text-sm">
                    <Award className="w-4 h-4 mr-2 text-red-500" />
                    Qualifications
                  </h4>
                  <div className="space-y-1">
                    {doctor.qualifications.map((qual, idx) => (
                      <p key={idx} className="text-xs text-slate-600 pl-4 relative">
                        <span className="absolute left-0 top-2 w-1 h-1 bg-red-500 rounded-full"></span>
                        {qual}
                      </p>
                    ))}
                  </div>
                </div>

                <div className="mb-3">
                  <h4 className="font-semibold text-slate-800 mb-2 flex items-center text-sm">
                    <MapPin className="w-4 h-4 mr-2 text-red-500" />
                    Experience
                  </h4>
                  <p className="text-xs text-slate-600">{doctor.experience}</p>
                </div>

                <div className="flex justify-center space-x-3 pt-3 border-t border-slate-100">
                  <button className="p-2 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors btn-scale">
                    <Facebook className="w-4 h-4 text-blue-600" />
                  </button>
                  <button className="p-2 bg-sky-50 rounded-lg hover:bg-sky-100 transition-colors btn-scale">
                    <Twitter className="w-4 h-4 text-sky-600" />
                  </button>
                  <button className="p-2 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors btn-scale">
                    <Linkedin className="w-4 h-4 text-blue-700" />
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
