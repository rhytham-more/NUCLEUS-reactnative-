import { Card, CardContent } from "@/components/ui/card"
import { Phone, Mail, MapPin, MessageCircle, Clock, HelpCircle } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

export default function ContactSection() {
  const faqs = [
    { question: "How do I book tests?", answer: "Use our Book Test section or call us directly" },
    { question: "How safe is sample collection?", answer: "We follow strict safety and hygiene protocols" },
    { question: "What if I miss my slot?", answer: "Contact us immediately to reschedule" },
  ]

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4 text-slate-800">Contact & Support</h2>

      <Card className="mb-6 border-slate-100 shadow-xl">
        <CardContent className="p-4">
          <h3 className="font-bold text-slate-800 mb-4">NUCLEUS Pathology Laboratory</h3>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <MapPin className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm text-slate-700">Near Bus Stand, Sinnar, Nashik, Maharashtra 422103</p>
                <button className="text-red-500 text-xs font-medium mt-1 btn-scale">Get Directions</button>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Phone className="w-5 h-5 text-red-500" />
              <div className="flex space-x-4">
                <button className="text-sm text-slate-700 hover:text-red-500 btn-scale">02555 230 724</button>
                <button className="text-sm text-slate-700 hover:text-red-500 btn-scale">02555 230 725</button>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Mail className="w-5 h-5 text-red-500" />
              <button className="text-sm text-slate-700 hover:text-red-500 btn-scale">info@nucleuslab.com</button>
            </div>

            <div className="flex items-center space-x-3">
              <Clock className="w-5 h-5 text-red-500" />
              <p className="text-sm text-slate-700">Mon-Sun: 8:00AM–8:00PM</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-3 gap-3 mb-6">
        <button className="gradient-green text-white p-3 rounded-xl text-sm font-medium flex flex-col items-center btn-scale shadow-md">
          <MessageCircle className="w-5 h-5 mb-1" />
          Chat
        </button>
        <button className="gradient-blue text-white p-3 rounded-xl text-sm font-medium flex flex-col items-center btn-scale shadow-md">
          <Phone className="w-5 h-5 mb-1" />
          Call Lab
        </button>
        <button className="gradient-purple text-white p-3 rounded-xl text-sm font-medium flex flex-col items-center btn-scale shadow-md">
          <MessageCircle className="w-5 h-5 mb-1" />
          Callback
        </button>
      </div>

      <Card className="mb-6 border-slate-100 shadow-lg">
        <CardContent className="p-4">
          <h3 className="font-semibold text-slate-800 mb-4">Send us a Message</h3>
          <form className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input id="name" placeholder="Enter your name" className="mt-1" />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="Enter your email" className="mt-1" />
            </div>
            <div>
              <Label htmlFor="mobile">Mobile Number</Label>
              <Input id="mobile" type="tel" placeholder="Enter your mobile number" className="mt-1" />
            </div>
            <div>
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" placeholder="Enter your message" rows={3} className="mt-1" />
            </div>
            <button className="w-full gradient-red text-white py-3 rounded-xl font-medium btn-scale shadow-md">
              Send Message
            </button>
          </form>
        </CardContent>
      </Card>

      <Card className="border-slate-100 shadow-lg">
        <CardContent className="p-4">
          <h3 className="font-semibold text-slate-800 mb-4 flex items-center">
            <HelpCircle className="w-5 h-5 mr-2 text-red-500" />
            Frequently Asked Questions
          </h3>
          <div className="space-y-3">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-slate-100 pb-3 last:border-b-0">
                <h4 className="font-medium text-slate-800 text-sm mb-1">{faq.question}</h4>
                <p className="text-slate-600 text-xs">{faq.answer}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
