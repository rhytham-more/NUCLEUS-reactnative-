import { Card, CardContent } from "@/components/ui/card"
import { Clock, Shield, Calendar } from "lucide-react"

export default function SampleCollection() {
  return (
    <div className="px-4 mb-6">
      <h2 className="text-lg font-bold text-slate-800 mb-4">Home Sample Collection</h2>

      <Card className="border-slate-100 bg-gradient-to-r from-green-50 to-emerald-50 shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Book Home Sample Collection</h3>
            <div className="w-10 h-10 gradient-green rounded-xl flex items-center justify-center shadow-md">
              <Calendar className="w-5 h-5 text-white" />
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <Shield className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
              <p className="text-slate-700 text-sm">Our phlebotomists uphold top safety and hygiene standards.</p>
            </div>

            <div className="flex items-start space-x-3">
              <Clock className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
              <p className="text-slate-700 text-sm">Next available slot: Tomorrow, 8AM</p>
            </div>
          </div>

          <div className="mt-4 p-3 bg-white rounded-lg border border-green-200 shadow-sm">
            <p className="text-slate-600 text-xs mb-2">
              <strong>Instructions:</strong> Please keep your ID ready. Fasting may be required for some tests.
            </p>
          </div>

          <button className="w-full mt-4 gradient-green text-white py-3 rounded-xl font-medium btn-scale shadow-md">
            Schedule Collection
          </button>
        </CardContent>
      </Card>
    </div>
  )
}
