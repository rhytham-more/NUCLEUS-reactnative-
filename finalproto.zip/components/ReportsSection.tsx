import { Card, CardContent } from "@/components/ui/card"
import { Lock, Download, TrendingUp, Brain } from "lucide-react"

export default function ReportsSection() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4 text-slate-800">My Reports</h2>

      <Card className="mb-6 border-slate-100 shadow-xl">
        <CardContent className="p-6 text-center">
          <div className="w-16 h-16 gradient-red rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Secure Login Required</h3>
          <p className="text-slate-600 mb-4 text-sm">Access your reports securely with OTP or password</p>
          <div className="space-y-3">
            <button className="w-full gradient-red text-white py-3 rounded-xl font-medium btn-scale shadow-md">
              Login with OTP
            </button>
            <button className="w-full bg-slate-100 text-slate-700 py-3 rounded-xl font-medium btn-scale">
              Login with Password
            </button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <Card className="border-slate-100 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 gradient-green rounded-xl flex items-center justify-center shadow-md">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-800">Digital Reports</h3>
                <p className="text-slate-600 text-sm">
                  Download digitally signed PDF reports, view trends, or share with your doctor
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-100 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 gradient-purple rounded-xl flex items-center justify-center shadow-md">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-800">AI Interpretation</h3>
                <p className="text-slate-600 text-sm">
                  Our AI explains your results—flagging out-of-range values with simple explanations
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-100 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 gradient-blue rounded-xl flex items-center justify-center shadow-md">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-800">Trend Analysis</h3>
                <p className="text-slate-600 text-sm">
                  Track your health parameters over time with visual charts and insights
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
