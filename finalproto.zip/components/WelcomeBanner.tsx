"use client"

import { useState, useEffect } from "react"

export default function WelcomeBanner() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const slides = [
    {
      title: "Welcome to NUCLEUS Pathology Lab",
      subtitle: "Your Trusted Diagnostic Partner",
      description:
        "Book lab tests, schedule home collection, access reports, and more – your health journey begins here.",
    },
    {
      title: "Monsoon Health Screening",
      subtitle: "Book Now for Special Discounts!",
      description: "Comprehensive health packages designed for the monsoon season. Stay healthy, stay protected.",
    },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [slides.length])

  return (
    <div className="relative mx-4 mt-4 mb-6">
      <div className="gradient-red rounded-3xl p-6 text-white overflow-hidden relative shadow-xl">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
        <div className="absolute top-1/2 right-1/4 w-16 h-16 bg-white/5 rounded-full"></div>

        <div className="relative z-10">
          <h1 className="text-xl font-bold mb-2 leading-tight">{slides[currentSlide].title}</h1>
          <p className="text-red-100 font-medium mb-3">{slides[currentSlide].subtitle}</p>
          <p className="text-red-50 text-sm mb-6 leading-relaxed">{slides[currentSlide].description}</p>

          <div className="flex space-x-3">
            <button className="bg-white text-red-500 px-4 py-2 rounded-xl font-medium text-sm flex-1 btn-scale hover:bg-red-50 transition-colors shadow-md">
              Book a Test
            </button>
            <button className="bg-white/20 text-white px-4 py-2 rounded-xl font-medium text-sm flex-1 btn-scale hover:bg-white/30 transition-colors">
              View Reports
            </button>
          </div>
        </div>

        <div className="flex justify-center mt-4 space-x-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-all btn-scale ${
                index === currentSlide ? "bg-white" : "bg-white/40"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
