import type React from "react"
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native"

interface DoctorCardProps {
  name: string
  specialization: string
  qualifications: string
  imageUrl: string
  onPress: () => void
}

const DoctorCard: React.FC<DoctorCardProps> = ({ name, specialization, qualifications, imageUrl, onPress }) => {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Image source={{ uri: imageUrl }} style={styles.image} resizeMode="cover" />
      <View style={styles.infoContainer}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.specialization}>{specialization}</Text>
        <Text style={styles.qualifications}>{qualifications}</Text>
      </View>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  image: {
    width: "100%",
    height: 180,
  },
  infoContainer: {
    padding: 16,
  },
  name: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333333",
    marginBottom: 4,
  },
  specialization: {
    fontSize: 16,
    color: "#2196F3",
    marginBottom: 4,
  },
  qualifications: {
    fontSize: 14,
    color: "#666666",
  },
})

export default DoctorCard
