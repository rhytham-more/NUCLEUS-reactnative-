import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Droplets, Heart, Shield, Zap, WormIcon as Virus } from "lucide-react"

interface PopularTestsProps {
  showAll?: boolean
}

export default function PopularTests({ showAll = false }: PopularTestsProps) {
  const tests = [
    {
      id: 1,
      name: "Complete Blood Count (CBC)",
      description: "Profile includes a comprehensive screen for blood health and metabolic state.",
      price: "₹299",
      time: "Reports within 24 hours",
      preparation: "No fasting required",
      icon: Droplets,
      popular: true,
    },
    {
      id: 2,
      name: "Lipid Profile",
      description: "Comprehensive cholesterol screening to assess cardiovascular risk.",
      price: "₹499",
      time: "Reports within 24 hours",
      preparation: "Fasting required: 10-12 hours before sample collection",
      icon: Heart,
      popular: true,
    },
    {
      id: 3,
      name: "Thyroid Panel",
      description: "Complete thyroid function assessment including TSH, T3, T4.",
      price: "₹699",
      time: "Reports within 24 hours",
      preparation: "No fasting required",
      icon: Zap,
      popular: false,
    },
    {
      id: 4,
      name: "Diabetes Screening",
      description: "Blood glucose and HbA1c testing for diabetes management.",
      price: "₹399",
      time: "Reports within 24 hours",
      preparation: "Fasting required: 8-10 hours before sample collection",
      icon: Shield,
      popular: true,
    },
    {
      id: 5,
      name: "COVID-19 RT-PCR",
      description: "Accurate COVID-19 detection with RT-PCR technology.",
      price: "Starting ₹499",
      time: "Reports within 24 hours",
      preparation: "No fasting required",
      icon: Virus,
      popular: true,
    },
  ]

  const displayTests = showAll ? tests : tests.slice(0, 3)

  return (
    <div className="px-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-slate-800">Popular Tests</h2>
        {!showAll && <button className="text-red-500 text-sm font-medium hover:text-red-600">View All</button>}
      </div>

      <div className="space-y-3 mb-6">
        {displayTests.map((test) => {
          const IconComponent = test.icon
          return (
            <Card key={test.id} className="border-slate-100 card-hover shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 gradient-red rounded-xl flex items-center justify-center flex-shrink-0 shadow-md">
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-slate-800 text-sm">{test.name}</h3>
                      {test.popular && (
                        <Badge className="bg-orange-100 text-orange-600 text-xs border-orange-200">Popular</Badge>
                      )}
                    </div>
                    <p className="text-slate-600 text-xs mb-3 leading-relaxed">{test.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-1 text-xs text-slate-500">
                          <Clock className="w-3 h-3" />
                          <span>{test.time}</span>
                        </div>
                        <p className="text-xs text-slate-500">{test.preparation}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-slate-800">{test.price}</p>
                        <button className="text-red-500 text-xs font-medium hover:text-red-600 btn-scale">
                          Book Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
