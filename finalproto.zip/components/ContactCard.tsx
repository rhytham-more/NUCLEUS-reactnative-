"use client"

import { Phone } from "lucide-react"

export default function ContactCard() {
  const handleCall = (number: string) => {
    window.open(`tel:${number}`, "_self")
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mx-4 -mt-4 relative z-10">
      <div className="flex items-center space-x-2 mb-3">
        <Phone className="w-5 h-5 text-red-500" />
        <span className="font-semibold text-red-500">Emergency Contact</span>
      </div>

      <div className="flex justify-between">
        <button
          onClick={() => handleCall("9890609022")}
          className="text-lg font-bold text-gray-800 hover:text-blue-600"
        >
          9890 60 9022
        </button>
        <button
          onClick={() => handleCall("02534060600")}
          className="text-lg font-bold text-gray-800 hover:text-blue-600"
        >
          0253 - 4060600
        </button>
      </div>
    </div>
  )
}
