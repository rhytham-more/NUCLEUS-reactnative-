import { Card, CardContent } from "@/components/ui/card"
import { FlaskRoundIcon as Flask, Heart, Activity, Users, ArrowRight } from "lucide-react"

interface ServicesSectionProps {
  showAll?: boolean
}

export default function ServicesSection({ showAll = false }: ServicesSectionProps) {
  const services = [
    {
      id: 1,
      title: "Pathology Tests",
      description: "Comprehensive blood and tissue analysis",
      icon: Flask,
    },
    {
      id: 2,
      title: "Health Checkups",
      description: "Complete health assessment packages",
      icon: Heart,
    },
    {
      id: 3,
      title: "Consultations",
      description: "Expert medical consultations",
      icon: Users,
    },
    {
      id: 4,
      title: "Blood Tests",
      description: "CBC, Lipid Profile, Glucose Tests",
      icon: Activity,
    },
  ]

  const displayServices = showAll ? services : services.slice(0, 3)

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Our Services</h2>

      <div className="space-y-3">
        {displayServices.map((service) => {
          const IconComponent = service.icon
          return (
            <Card key={service.id} className="hover:shadow-md transition-shadow">
              <CardContent className="flex items-center p-4">
                <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mr-4">
                  <IconComponent className="w-6 h-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-800">{service.title}</h3>
                  <p className="text-sm text-gray-600">{service.description}</p>
                </div>
                <ArrowRight className="w-5 h-5 text-gray-400" />
              </CardContent>
            </Card>
          )
        })}
      </div>

      {!showAll && (
        <button className="flex items-center justify-center w-full mt-4 text-blue-600 font-medium">
          View All Services
          <ArrowRight className="w-4 h-4 ml-1" />
        </button>
      )}
    </div>
  )
}
