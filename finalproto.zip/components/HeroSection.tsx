"use client"

import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export default function HeroSection() {
  const router = useRouter()

  return (
    <div className="bg-blue-500 text-white p-6 rounded-b-3xl">
      <div className="space-y-4">
        <h1 className="text-2xl font-bold leading-tight">Nucleus Pathology Laboratory and Clinic</h1>
        <p className="text-lg font-semibold text-blue-100">Your Health Is Our Priority</p>
        <p className="text-blue-100 text-sm">
          Providing high-quality healthcare services to patients of all ages in Indira Nagar, Nashik.
        </p>

        <div className="flex space-x-3 pt-4">
          <Button
            onClick={() => router.push("/appointment")}
            className="bg-white text-blue-600 hover:bg-blue-50 flex-1"
          >
            Book Appointment
          </Button>
          <Button
            variant="outline"
            className="border-white text-white hover:bg-white hover:text-blue-600 flex-1 bg-transparent"
          >
            Our Services
          </Button>
        </div>
      </div>
    </div>
  )
}
