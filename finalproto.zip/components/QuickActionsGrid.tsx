"use client"

import { TestTube, FileText, Home, UserCheck, MapPin, Phone } from "lucide-react"

interface QuickActionsGridProps {
  onTabChange: (tab: string) => void
}

export default function QuickActionsGrid({ onTabChange }: QuickActionsGridProps) {
  const actions = [
    { icon: TestTube, label: "Book Test", color: "gradient-blue", tab: "book-test" },
    { icon: FileText, label: "My Reports", color: "gradient-green", tab: "reports" },
    { icon: Home, label: "Home Collection", color: "gradient-purple", tab: "book-test" },
    { icon: UserCheck, label: "Consult Expert", color: "gradient-red", tab: "doctors" },
    { icon: MapPin, label: "Lab Info", color: "bg-gradient-to-r from-pink-500 to-rose-500", tab: "contact" },
    { icon: Phone, label: "Contact Us", color: "bg-gradient-to-r from-indigo-500 to-blue-500", tab: "contact" },
  ]

  return (
    <div className="px-4 mb-6">
      <h2 className="text-lg font-bold text-slate-800 mb-4">Quick Actions</h2>
      <div className="grid grid-cols-3 gap-4">
        {actions.map((action, index) => {
          const IconComponent = action.icon
          return (
            <button
              key={index}
              onClick={() => onTabChange(action.tab)}
              className="bg-white rounded-2xl p-4 shadow-lg border border-slate-100 card-hover group"
            >
              <div
                className={`w-12 h-12 ${action.color} rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform shadow-md`}
              >
                <IconComponent className="w-6 h-6 text-white" />
              </div>
              <p className="text-sm font-medium text-slate-700 text-center">{action.label}</p>
            </button>
          )
        })}
      </div>
    </div>
  )
}
