import { ArrowLeft, Facebook, Linkedin, Twitter, MapPin, Award } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"

export default function DoctorsPage() {
  const doctors = [
    {
      name: "Dr. MEENA P. SONONE (Dhole)",
      position: "Consultant Chest Physician, Intensivist and Diabetologist",
      qualifications: [
        "M.B.B.S. MGM College Indore (2003)",
        "D.T.C.D. PG Diploma in TB and Chest Diseases, MGM College Indore (2008)",
        "I.D.C.C.M. Indian Diploma, K.E.M. Hospital Pune (2010)",
        "F.I.D. Fellowship in Diabetes, Apollo Mediversity, Hyderabad (2016)",
      ],
      mmcReg: "2014/04/1628",
      experience: "Ex Consultant: Apollo Hospitals, Nashik; Ashoka Medicover Nashik",
      image: "/placeholder.svg?height=200&width=200",
    },
    {
      name: "Dr. PANKAJ A. SONONE",
      position: "Consultant Pathologist & Occupational Health Specialist",
      qualifications: [
        "M.B.B.S. Government Medical College, Nagpur (2004)",
        "D.C.P. PG Diploma, VM Govt. Medical College, Solapur (2010)",
        "M.H.A. Masterclass in Hospital Administration, Apollo Mediversity (2023)",
        "A.F.I.H. Asso. Fellow in Industrial Health, Regional Labour Inst. Kolkata (2024)",
      ],
      mmcReg: "2005/03/1594",
      experience: "Ex Consultant: Deenanath Mangeshkar Hospital, Pune; Dr. Lal Path Labs, Delhi",
      image: "/placeholder.svg?height=200&width=200",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 max-w-md mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-500 to-pink-500 text-white p-4">
        <div className="flex items-center space-x-3 mb-4">
          <button>
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">Our Doctors</h1>
        </div>
        <p className="text-red-100 text-sm">Meet our experienced medical professionals</p>
      </div>

      {/* Doctors List */}
      <div className="p-4 space-y-6">
        {doctors.map((doctor, index) => (
          <Card key={index} className="border-slate-100 overflow-hidden">
            <CardContent className="p-0">
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 text-center">
                <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden bg-white shadow-lg">
                  <Image
                    src={doctor.image || "/placeholder.svg"}
                    alt={doctor.name}
                    width={96}
                    height={96}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="font-bold text-lg text-slate-800 mb-1">{doctor.name}</h3>
                <p className="text-red-600 font-medium text-sm mb-2">{doctor.position}</p>
                <Badge className="bg-blue-100 text-blue-600 text-xs">MMC Reg. No: {doctor.mmcReg}</Badge>
              </div>

              <div className="p-4">
                <div className="mb-4">
                  <h4 className="font-semibold text-slate-800 mb-2 flex items-center">
                    <Award className="w-4 h-4 mr-2 text-red-500" />
                    Qualifications
                  </h4>
                  <ul className="space-y-1">
                    {doctor.qualifications.map((qual, idx) => (
                      <li key={idx} className="text-sm text-slate-600 pl-4 relative">
                        <span className="absolute left-0 top-2 w-1 h-1 bg-red-500 rounded-full"></span>
                        {qual}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mb-4">
                  <h4 className="font-semibold text-slate-800 mb-2 flex items-center">
                    <MapPin className="w-4 h-4 mr-2 text-red-500" />
                    Experience
                  </h4>
                  <p className="text-sm text-slate-600">{doctor.experience}</p>
                </div>

                <div className="flex justify-center space-x-4 pt-4 border-t border-slate-100">
                  <button className="p-2 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                    <Facebook className="w-5 h-5 text-blue-600" />
                  </button>
                  <button className="p-2 bg-sky-50 rounded-lg hover:bg-sky-100 transition-colors">
                    <Twitter className="w-5 h-5 text-sky-600" />
                  </button>
                  <button className="p-2 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                    <Linkedin className="w-5 h-5 text-blue-700" />
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
