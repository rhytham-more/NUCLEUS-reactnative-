"use client"

import { useState } from "react"
import Header from "@/components/Header"
import BottomNavigation from "@/components/BottomNavigation"
import WelcomeBanner from "@/components/WelcomeBanner"
import QuickActionsGrid from "@/components/QuickActionsGrid"
import PopularTests from "@/components/PopularTests"
import HealthFeed from "@/components/HealthFeed"
import AboutSection from "@/components/AboutSection"
import SampleCollection from "@/components/SampleCollection"
import DoctorsSection from "@/components/DoctorsSection"
import ReportsSection from "@/components/ReportsSection"
import ContactSection from "@/components/ContactSection"
import Footer from "@/components/Footer"

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("home")

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 max-w-md mx-auto relative">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="pb-20">
        {activeTab === "home" && (
          <div className="animate-fade-in">
            <WelcomeBanner />
            <QuickActionsGrid onTabChange={setActiveTab} />
            <PopularTests />
            <AboutSection />
            <SampleCollection />
            <HealthFeed />
            <Footer />
          </div>
        )}

        {activeTab === "book-test" && (
          <div className="p-4 animate-fade-in">
            <h2 className="text-2xl font-bold mb-4 text-slate-800">Book a Test</h2>
            <PopularTests showAll />
          </div>
        )}

        {activeTab === "reports" && (
          <div className="animate-fade-in">
            <ReportsSection />
          </div>
        )}

        {activeTab === "health" && (
          <div className="p-4 animate-fade-in">
            <h2 className="text-2xl font-bold mb-4 text-slate-800">Health & Wellness</h2>
            <HealthFeed expanded />
          </div>
        )}

        {activeTab === "profile" && (
          <div className="p-4 animate-fade-in">
            <h2 className="text-2xl font-bold mb-4 text-slate-800">Profile</h2>
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100">
              <div className="text-center">
                <div className="w-20 h-20 gradient-blue rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white text-2xl">👤</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Family Management</h3>
                <p className="text-slate-600 mb-4">Add family profiles, book group tests, track others' reports</p>
                <button className="gradient-blue text-white px-6 py-3 rounded-xl font-medium btn-scale">
                  Manage Family
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === "contact" && (
          <div className="animate-fade-in">
            <ContactSection />
          </div>
        )}

        {activeTab === "doctors" && (
          <div className="animate-fade-in">
            <DoctorsSection />
          </div>
        )}
      </main>

      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  )
}
